<?php
session_start();
include("./KFC_ADMIN/database/database.php");

if(isset($_POST['add-to-cart'])){
    $user_id = $_SESSION['login_user_success_abc_xyz']['user_id'];
   $pid = $_POST['product_id'];
   $wheres = "user_id =".$user_id." AND pid =".$pid;
  $pro_price = (int)$_POST['product_price'];
   $add_op_prices =(int)0;
   if(isset($_POST['add_op_checkbox'])){
   $add_pr_id[] = $_POST['add_op_checkbox'];
   $add_pr_id = $add_pr_id[0];
   $x = count($add_pr_id);
   $add_pr_ids  = "";
    for($i=0; $i<$x; $i++){
        $where = 'add_op_id ='.$add_pr_id[$i];
        $db_obj->select("add_op_product",'price',null,$where,null,null);
        $result = $db_obj->getResult();
        $result = (int)$result[0][0]['price'];
        $add_op_prices = $add_op_prices+$result;
        $add_pr_ids .=$add_pr_id[$i].",";

       
    }
   
    $add_pr_ids  = rtrim($add_pr_ids,",");
   }else{
    $add_pr_ids = "";
   }
  $cid_amount =  $add_op_prices + $pro_price;
   $db_obj->update('cart',['quantity'=>1 ,'Amount'=>$cid_amount, 'totalAmount'=>$cid_amount,'option_pr_ids'=>$add_pr_ids],$wheres);
   $_SESSION['msg'] = "Edit Successful";
   header("location:cart.php");
}
include("./include/header.php");
include("./template/__singleUpdate.php");
include("./include/footer.php");


?>

