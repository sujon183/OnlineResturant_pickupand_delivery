<?php
session_start();
include("./KFC_ADMIN/database/database.php");
if(isset($_SESSION['login_user_success_abc_xyz'])){
    header("location: product.php");
}
if(isset($_POST['login_btn'])){
    $email = ($_POST['mail']);
    $password = $_POST['pass'];
    $haspass = sha1(md5($password));
    $where = "user_mail = '{$email}'";
    $db_obj->select("user_info","*",null,$where,null,null);
    $result = $db_obj->getResult();
    $result = $result[0];
    $x = count($result);
    if(empty($email) || empty($password)){
        $_SESSION['msg'] = "Something is happened wrong";
        return false;
    }else{
        if($x == 1){
            $act = $result[0]['user_active'];
            if($act == 'active'){
                $dbpass = $result[0]['user_password'];
            if($haspass == $dbpass){
                $name = $result[0]['user_name'];
                $user_id = $result[0]['user_id'];
                $_SESSION['login_user_success_abc_xyz'] = 
                ['user_name'=>$name,'user_id'=>$user_id,'user_mail'=>$email];
                header("location: product.php");
            }else{
                $_SESSION['msg'] = "Password does not match";
                header("location: login.php");
                return false;   
            }
            }else{
                $_SESSION['msg'] = "Please Checked your Email to active your account";
                header("location: login.php");
                return false;
            }
        }else{
            $_SESSION['msg'] = "Please Register First";
            header("location: signup.php");
            return false;
        }
    }
    
}












include("./include/signupHeader.php");
include("./template/__login.php");
include("./include/signupFooter.php");
?>