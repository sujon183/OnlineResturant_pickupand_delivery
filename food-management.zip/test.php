<?php
$x ="Sujonhossain10";
echo sha1(md5($x));


?>