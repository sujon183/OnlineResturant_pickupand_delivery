  <!-- main  -->
  <?php if(isset($_SESSION['msg'])){ ?>
    <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
  <?php  unset($_SESSION['msg']); } ?>
  <section id="main">
     
     <div class="container">

         <h1 class="text-center font-size-20 text-uppercase mb-5 font-kurale text-danger bold">kfc</h1>
         <div class="row justify-content-center">
            <div class="col-md-6 col-12">
             <div class="card">
                 <div class="card-header">
                     <div class="d-flex justify-content-between align-items-center">
                         <h3 class="text-uppercase color-secondary font-size-20">Register Form</h3>
                         <h3><a href="product.php" class="nav-link">Back to Home</a></h3>
                     </div>
                    
                 </div>
                 <div class="card-body">
                     <div class="form-container">
                         <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data" method="post">
                             <div class="form-group my-2 font-size-18">
                                 <label>Full Name</label>
                                 <input type="text" name="full_name" class="form-control font-size-18">
                             </div>
                             <div class="form-group my-2 font-size-18">
                                 <label>Email</label>
                                 <input type="email" name="mail" class="form-control font-size-18">
                             </div>
                             <div class="form-group my-2 font-size-18">
                                 <label>Password</label>
                                 <div class="input-group">
                                    <input type="password" name="pass" id="show-pass" class="form-control font-size-18"
                                    pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title=" Password Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                                    <div class="input-group-addon border px-3 bg-light">
                                        <div id="show-pass-btn"><span class="fa fa-eye-slash" aria-hidden="true"></span></div>
                                    </div>
                                </div>
                            </div>
                             <div class="form-group my-2 font-size-18">
                                 <label>Confirm Password</label>
                                 <div class="input-group">
                                    <input type="password" name="cpass" id="show-cpass" class="form-control font-size-18">
                                    <div class="input-group-addon border px-3 bg-light">
                                        <div id="show-cpass-btn"><span class="fa fa-eye-slash" aria-hidden="true"></span></div>
                                    </div>
                                 </div>
                             </div>
                             <div class="group my-4">
                                 <button class="form-control btn color-secondary-bg text-white font-size-20" name="user_register" type="submit">Submit</button>
                             </div>
                         </form>
                     </div>
                 </div>
                 <div class="card-footer">
                     <div class="text-center"><h3><a href="login.php">I already have an account</a></h3></div>
                 </div>
             </div>
            </div>
         </div>
     </div>


 </section>
 <!-- !main  -->
 <!-- show password method  for the user -->
 <script>
    $(document).ready(function(){
        // password 
        let show_pass_btn = $("#show-pass-btn");
        let show_pass = $("#show-pass");
        show_pass_btn.on('click',function(evant){
            evant.preventDefault();
            if(show_pass.attr('type') == "password"){
                show_pass.attr('type','text'); 
                show_pass_btn.find('span').removeClass('fa-eye-slash');
                show_pass_btn.find('span').addClass('fa-eye');
            }else if(show_pass.attr('type') == "text"){
                show_pass.attr('type','password'); 
                show_pass_btn.find('span').removeClass('fa-eye');
                show_pass_btn.find('span').addClass('fa-eye-slash');
            }
           
        });
        // cpassword 
        let show_cpass_btn = $("#show-cpass-btn");
        let show_cpass = $("#show-cpass");
        show_cpass_btn.on('click',function(evant){
            evant.preventDefault();
            if(show_cpass.attr('type') == "password"){
                show_cpass.attr('type','text'); 
                show_cpass_btn.find('span').removeClass('fa-eye-slash');
                show_cpass_btn.find('span').addClass('fa-eye');
            }else if(show_cpass.attr('type') == "text"){
                show_cpass.attr('type','password'); 
                show_cpass_btn.find('span').removeClass('fa-eye');
                show_cpass_btn.find('span').addClass('fa-eye-slash');
            }
           
        });

    });
 </script>