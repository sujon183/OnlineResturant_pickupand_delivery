  <!-- main  -->
  
  <section id="main">
        <div class="productContainer"><div class="bars"><div></div></div></div>
    
            <!-- my cart  -->
                <section id="cart" class="my-5">
                    <div class="productContainer py-5">
                        <h2 class="font-rale cart-title">My Cart</h2>
                        <div class="row ">
                            <?php
                            $user_id = $_SESSION['login_user_success_abc_xyz']['user_id'];
                            $where = "user_id = '{$user_id}'";
                            $join = "INNER JOIN product ON cart.pid = product.pid
                            LEFT JOIN offer_product ON cart.of_id = offer_product.of_id
                            ";
                            $db_obj->selectInner("cart","*",$join,$where,null,null);
                           
                            $cartResult = $db_obj->getjoinResult();
                            $cartResult = $cartResult[0];
                            $count_cart_item = count($cartResult);
                           
                            // echo "<pre>";
                            // print_r($cartResult);
                            // echo "</pre>";
                            ?>
                            <input hidden id="total-cart-item" value="<?php echo $count_cart_item; ?>">
                            
                            <?php
                            for($x=0; $x<$count_cart_item; $x++){
                            ?>
                            
                            <div class="col-md-8 col-12">
                                <div class="peoductList">
                                    <div class="row shadow justify-content-center align-items-center">
                                        <div class="col-3"><img src="./KFC_ADMIN/assets/images/<?php echo $cartResult[$x]['pro_img']; ?>" class="cart-img"></div>
                                        <div class="col-6">
                                            <div class="row justify-content-center align-items-center">
                                                <div class="col-md-6 col-12">
                                                    <h3 class="font-roboto"><?php echo $cartResult[$x]['pro_name']; ?> </h3>
                                                    <?php 
                                                    $op_add_pr = $cartResult[$x]['option_pr_ids'];
                                                    if($op_add_pr != null){ ?>
                                                    <span class="pl-5 d-block font-size-16"><strong>details <span class="fa-solid fa-angle-down" onclick='details("<?php echo "details".$cartResult[$x]["cid"];  ?>")' ></span></strong></span>
                                                    <?php
                                                        $op_add_arr = explode(',',$op_add_pr);
                                                     $count = count($op_add_arr); ?>
                                                     <div id="<?php echo'details'.$cartResult[$x]['cid'];  ?>" class="mb-2 display-none">
                                                     <?php
                                                     for($i=0; $i<$count; $i++){
                                                        $whereop = "add_op_id = '{$op_add_arr[$i]}'";
                                                        $db_obj->select('add_op_product','name',null,$whereop,null,null);
                                                        $add_op_result = $db_obj->getResult();
                                                        $name = $add_op_result[0][0]['name'];
                                                       ?>
                                                       
                                                            <p class="font-size-14 text-black-50"><?php echo $name." &nbsp; &nbsp; &nbsp;"; ?></p>
                                                       
                                                       <?php
                                                     } // $i end
                                                     ?>
                                                     </div>
                                                   <?php }  // $if end
                                                    
                                                    ?>
                                                    <div>
                                                        <a href="#" class="text-danger font-size-16 my-3 px-2">Delate</a>
                                                        <a href="#" class="text-success font-size-16 my-3">Edit</a>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-12">
                                                    <div class="cart-input-btn">
                                                        <button data-id="pro<?php echo $x+1; ?>" class="qty_down"><span class="fa-solid fa-minus" ></span></button>
                                                        <input name="qty[]" type="number" value="1" data-id="pro<?php echo $x+1; ?>"  class="qty_input text-dark" disabled placeholder="1">
                                                        <button data-id="pro<?php echo $x+1; ?>" class="qty_up" ><span class="fa-solid fa-plus"></span></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <?php
                                                 $pro_regu = $cartResult[$x]['pro_regular_price'];
                                                 $op_add_pr = $cartResult[$x]['option_pr_ids'];
                                                    if($op_add_pr != null){ 
                                                        $op_add_arr = explode(',',$op_add_pr);
                                                     $count = count($op_add_arr); 
                                                       for($i=0; $i<$count; $i++){
                                                        $whereop = "add_op_id = '{$op_add_arr[$i]}'";
                                                        $db_obj->select('add_op_product','price',null,$whereop,null,null);
                                                        $add_op_result = $db_obj->getResult();
                                                        $price = $add_op_result[0][0]['price'];
                                                        $pro_regu =$pro_regu+ $price;
                                                       } // for loop
                                                    } // if loop
                                            ?>
                                            <input hidden class="cart_id" value="<?php echo $cartResult[$x]['cid']; ?>" data-id="pro<?php echo $x+1; ?>">
                                            <input hidden  type="text" class="cart_item_price" data-id="pro<?php echo $x+1; ?>" value="<?php echo $pro_regu; ?>">
                                            <input hidden type="text" class="cart_item_prices <?php echo 'cart_item_price'.$x+1; ?>" data-id="pro<?php echo $x+1; ?>" value="<?php echo $pro_regu; ?>">
                                            <div class="price"><span  type="number" class="pro_price" data-id="pro<?php echo $x+1; ?>"><?php echo $pro_regu; ?></span><span class="fa-solid fa-euro px-2"></span></div>
                                        
                                        </div>
                                    </div>

                                   
                                </div>
                            </div>
                            <?php } ?>
                            <div class="col-12 col-md-4 shadow">
                                <div class="container py-2">
                                    <h1 class="font-roboto py-4"><?php echo $count_cart_item; ?> Articles</h1>
                                    <hr>
                                    <h2 class="font-rale promo-title">Use Promo Code</h2>
                                    <div class="promoCode">
                                        <input type="text" id="prom_input" class="prom_input"> 
                                        <button id="promoAply" class="btn-dark apply">Apply</button>
                                    </div>
                                    <hr class="mt-5">
                                    <div class="d-flex align-items-center justify-content-between py-3">
                                        <h3 class="subtotal color-black-50">Subtotal</h3>
                                        <h3 class="subtotal color-black-50" id="subtotal">165 <span class="fa-solid fa-euro"></span> </h3>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between py-3">
                                        <h3 class="totlal text-dark">Total</h3>
                                        <h3 class="total text-dark" id="total">165 <span class="fa-solid fa-euro"></span> </h3>
                                        <input hidden type="number" id="total_id" name="totalamount">
                                    </div>
                                    <button class="color-primary-bg border-0 w-100 my-3 py-2 font-size-16 text-white">Confirm</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            <!-- !my cart  -->

       

    </section>
    <!-- !main  -->
    <script>



//
          function details(w){
        let detailspr = document.getElementById(w);
            console.log(detailspr);
            detailspr.classList.toggle("display-none");
          }

          $(document).ready(function(){

            // product total price count 
    function subtotal(){
        let total_item = $("#total-cart-item").val();
        let total_id = $("#total_id");
        let subtotal_id = $("#subtotal");
        let total = $("#total");
  let subtotal=parseInt(0);

    for(let j=0; j<total_item; j++){
        let price = $('.cart_item_price'+(j+1)).val();
        let priceint = parseInt(price);
    
        subtotal = (subtotal+priceint);
        
    }
    subtotal_id.html(subtotal);
    total.html(subtotal);
    total_id.val(subtotal);
    
    }
    subtotal();
             
            // product value count per item up 
        let total_cart_item = $("#total-cart-item").val();
        let $qty_up_bt = $('.qty_up');
        let $qty_down_bt = $('.qty_down');
        $qty_up_bt.click(function(e){
            e.preventDefault();
        let $input = $(`.qty_input[data-id='${$(this).data("id")}']`);
        let $cart_item_price = $(`.cart_item_price[data-id='${$(this).data("id")}']`);
        let $cart_item_prices = $(`.cart_item_prices[data-id='${$(this).data("id")}']`);
        let $cart_item_id = $(`.cart_id[data-id='${$(this).data("id")}']`);
        let $pro_price = $(`.pro_price[data-id='${$(this).data("id")}']`);
        let car_id_val = $cart_item_id.val();
        let price_val = $cart_item_price.val();
        let qty_up_input_value = $input.val();
            qty_up_input_value++;
            let cng_price = price_val * qty_up_input_value;
            $pro_price.html(cng_price);
             $cart_item_prices.val(cng_price);
           subtotal();
          

});

// product down value  count

$qty_down_bt.click(function(e){
        e.preventDefault();
        let $input = $(`.qty_input[data-id='${$(this).data("id")}']`);
        let $cart_item_price = $(`.cart_item_price[data-id='${$(this).data("id")}']`);
        let $cart_item_prices = $(`.cart_item_prices[data-id='${$(this).data("id")}']`);
        let $cart_item_id = $(`.cart_id[data-id='${$(this).data("id")}']`);
        let $pro_price = $(`.pro_price[data-id='${$(this).data("id")}']`);
        let car_id_val = $cart_item_id.val();
        let price_val = $cart_item_price.val();
        let qty_up_input_value = $input.val();
            if(qty_up_input_value !=1){
            qty_up_input_value--;
            let cng_price = price_val * qty_up_input_value;
            $pro_price.html(cng_price);
            $cart_item_prices.val(cng_price);
           subtotal();
        }
        subtotal();
});



      // promo code 
      $("#promoAply").click(function(){
        let code = $("#prom_input").val();
        let total_amount = $("#total_id").val();
        alert(total_amount);
      });


          });
    </script>