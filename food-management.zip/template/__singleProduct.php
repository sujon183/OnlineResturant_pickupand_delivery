<?php 
    if(isset($_GET["id"])){
        $pid = $_GET['id'];
        $where = "pid = ".$pid;
        $join = "RIGHT JOIN menu ON product.menu_id = menu.menu_id";
        $db_obj->selectInner("product","*",$join,$where,null,null);

        $result = $db_obj->getjoinResult();
        $result = $result[0][0];

?>

<?php
if(isset($_SESSION['msg'])){
    ?>
    <div class="container" style="margin: 10rem;">
    <div class="row justify-content-center">
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
  <h3><?php echo $_SESSION['msg']; ?></h3>
  <button type="button" id="close" class="close" data-dismiss="alert" aria-label="Close">
    
    <span aria-hidden="true">&times;</span>
  </button>
</div>
    </div>
</div>
    <?php
    unset($_SESSION['msg']);
}

?>


    <!-- single product  -->
<section id="singleProduct">
    <div class="container py-1">
        <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
            <div class="row">
                        <div class="col-12 col-md-8">
                            <h3 class="text-black-50 mb-4"><?php echo $result['menu_name']; ?> > <?php echo $result['pro_name']; ?></h3>
                            <img src="./KFC_ADMIN/assets/images/<?php echo $result['pro_img']; ?>" alt="Single Product" class="single-product-images">
                        </div>
                        <input value="<?php echo $pid; ?>" name="product_id" hidden>
                        <div class="col-12 col-md-4 shadow px-5">
                            <div class="bars">
                                <div></div>
                            </div>
                            <div class="product-text d-flex flex-column justify-content-center">
                                <h3 class="font-kurale mt-5"><?php echo $result["pro_name"]; ?></h3>
                                <input value="<?php echo $result["pro_regular_price"];  ?>" hidden name="product_price">
                                <h4 class="font-kurale my-2 bold"><?php echo $result["pro_regular_price"]; ?><span class="fa-solid fa-euro"></span></h4>
                                <h5 class="font-rale my-2">
                                    <?php echo $result["pro_desc"]; ?>
                                </h5>
                            </div>
                            <div class="product-btn d-flex justify-content-center mt-1">
                                <?php
                                    if(isset($_SESSION['login_user_success_abc_xyz'])){
                                        $user_id = $_SESSION['login_user_success_abc_xyz']['user_id'];
                                        $whereuser = "user_id = '{$user_id}' ";
                                       $db_obj->select("cart",'pid',null,$whereuser,null,null);
                                       $user_info = $db_obj->getResult();
                                       $user_info = $user_info[0];
                                       $count = count($user_info);
                                       $indexArray = [];
                                       for($x=0; $x<$count; $x++){
                                          array_push($indexArray,$user_info[$x]['pid']);
                                       }
                                        if(in_array($pid,$indexArray)){  ?>
                                           
                                             <div id="productExixts" class="btn color-primary-bg text-white px-5 font-size-18">Order</div> 
                                            <?php
                                        }else{
                                        ?>
                                <button id="add-to-cart" name="add-to-cart" class="btn color-primary-bg text-white">Order</button>    
                                <?php
                                        } // if in array method
                            }else{ ?>
                                    <a href="login.php" class="btn color-primary-bg text-white font-size-18">Order</a>
                               <?php } ?>
                            </div>
                        
                        </div>
            </div>
                    <!-- // option Product  -->
            <section id="product">
                <div class="productContainer py-5">
                <?php 
                $op_id =  $result['option_pro_id'];
                $op_id = explode(',',$op_id);
                $total_op_id = count($op_id); 
                ?>
                <input value="<?php echo $total_op_id ?>" id="total_op_id" hidden>
                    <div class="RightNow">
                        <div id="offer_products">

                        </div>
                    <?php
                        for($k=0; $k<$total_op_id; $k++){
                            $id = $op_id[$k];
                            $where = "op_id =".$id;
                            $sql = "SELECT op_type FROM op_product WHERE $where";
                            $db_obj->sql($sql);
                            $sqlresult = $db_obj->getsqlResult();
                            $op_type = $sqlresult[0][0]['op_type'];
                            $db_obj->select('add_op_product',"*",null,$where,null,null);
                            $products = $db_obj->getResult();
                            $products = $products[0];
                            $products_count = count($products);
                                    
                    ?>
                    <input value="<?php echo $id; ?>" id="<?php echo 'op_id'.$k+1; ?>" hidden>
                            <input hidden value="<?php echo $op_type; ?>" id="<?php echo 'op_type'.$k+1; ?>">
                            <h1 class="font-kurale py-4 font-size-20 text-bold my-5">Add on Product</h1>
                            <input value="<?php echo $products_count ?>" id="<?php echo 'products_count'.$k+1; ?>" hidden>
                        <div class="flexingRow border" id="row<?php echo $k+1; ?>">
                            <?php for($x=0; $x<$products_count; $x++){ ?>
                                <?php  $pro_id = $products[$x]['add_op_id']; ?>
                                
                                <input name="add_op_id[]" value="<?php echo $pro_id?>" id="<?php echo 'add_op_id'.$x+1; ?>" hidden>
                                <div class="free_product border p-3" id="<?php echo 'free_product'.$pro_id; ?>">
                                    <div class="free-product-checkbox display-none">
                                        <input type="checkbox" name="add_op_checkbox[]" value="<?php echo $pro_id; ?>">
                                    </div>
                                    <div class="product-desc">
                                        <div class="productImages"><img src="./KFC_ADMIN/assets/images/<?php echo $products[$x]['op_pr_img']; ?>"></div>
                                    </div>
                                                
                                   <div class="text-center d-flex flex-column bg-white shadow pt-1 pb-3">
                                      <h4 class="color-black-50 text-center my-2"><?php echo $products[$x]['price']; ?>
                                        <span class="fa-solid fa-euro"></span> 
                                      </h4>
                                      <h3 class="text-center font-rale text-black bold mb-3 mt-2"><?php echo $products[$x]['name']; ?></h3>

                                  </div>
                                </div>
                           <?php } // $x loop end ?>
                        
                        </div>
                        <?php } // end $k loop ?>
                    </div>
                </div>
            </section>
            
                   
        </form>
                <?php } // isset loop is end ?>
    </div>
</section>
<div class="abc"></div>
  <script>
    $(document).ready(function(){
        let total_op_id = $("#total_op_id").val();
        let $row,$rowid,op_type,add_op_id,free_product;
        for(let k =0; k<total_op_id; k++){
            let op_id = $("#op_id"+(k+1)).val();
           let  $row = "row"+(k+1);
           let  $rowid = $("#"+$row);
           let op_type = $("#op_type"+(k+1)).val();
           let products_count = $("#products_count"+(k+1)).val();
          function unselecetd(v){
            for(let a=0; a<products_count; a++){
                let add_op_id = $rowid.find("#add_op_id"+(a+1)).val();
                
               if(v != add_op_id){
                let free_product =  $("#free_product"+add_op_id);
                let checked_input_div = free_product.find(".free-product-checkbox");
                checked_input_div.find('input').prop('checked',false);
                checked_input_div.addClass("display-none");
                
               }
            }
          }
           for(let j=0; j< products_count; j++){
            let add_op_id = $rowid.find("#add_op_id"+(j+1)).val();
            let free_product =  $("#free_product"+add_op_id);
            let checked_input_div = free_product.find(".free-product-checkbox");

            $("#free_product"+add_op_id).click(function(){
                if(op_type != 'single_selection'){
                    let checked_value = checked_input_div.find('input').is(':checked');
                    if(checked_value == false){
                        checked_input_div.find('input').prop('checked',true);
                    }else{
                        checked_input_div.find('input').prop('checked',false);
                    }
                    checked_input_div.toggleClass('display-none');
                    
                   
                }else{
                let checked_value = checked_input_div.find('input').is(':checked');
                if(checked_value == true){
                    checked_input_div.find('input').prop('checked',false);
                    checked_input_div.addClass('display-none');
                }else{
                    unselecetd( add_op_id);
                    checked_input_div.find('input').prop('checked',true);
                    checked_input_div.removeClass("display-none");
            }
            }
            });
    
          
           }  
          
        
          
            
        }// k for loop end 
        $(".close").click(function(){
            $(".fade").fadeOut();
        });
        // exists product 
        $("#productExixts").click(function(){
            $.ajax({
                url:'./action/action.php',
                type:'POST',
                success:function(){
                    alert("This product already Exists in Your Cart Page");
                }
            
            });

        });
    }); // end ready function 
  </script>