   <!-- main  -->
   <section id="main">
     
     <div class="container">
         <h1 class="text-center font-size-20 text-uppercase mb-5 font-kurale text-danger bold">kfc</h1>
         <div class="row justify-content-center">
            <div class="col-md-6 col-12">
             <div class="card">
                 <div class="card-header">
                     <div class="d-flex justify-content-between align-items-center">
                         <h3 class="text-uppercase color-secondary font-size-20">Login Form</h3>
                         <h3><a href="#" class="nav-link">Back to Home</a></h3>
                     </div>
                    
                 </div>
                 <div class="card-body">
                     <div class="form-container">
                         <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST">
                             <div class="form-group my-2 font-size-18">
                                 <label> Email</label>
                                 <input type="email" name="mail" class="form-control font-size-18">
                             </div>
                             <div class="form-group my-2 font-size-18">
                                 <label>Password</label>
                                 <div class="input-group">
                                   <input type="password" name="pass" class="form-control font-size-18" id="show_pass">
                                   <div class="input-group-addon border px-3 bg-light" id="show_pass_btn">
                                        <span class="fa fa-eye-slash"></span>
                                   </div>
                                 </div>
                             </div>
                             <div class="group my-4">
                                 <button name="login_btn" class="form-control btn color-secondary-bg text-white font-size-20">Login</button>
                             </div>
                         </form>
                     </div>
                 </div>
                 <div class="card-footer">
                     <div class="text-center"><h3><a href="signup.php">I  have no account ? click here</a></h3></div>
                 </div>
             </div>
            </div>
         </div>
     </div>


 </section>
 <!-- !main  -->
 <script>
    $(document).ready(function(){
              // password 
              let show_pass_btn = $("#show_pass_btn");
        let show_pass = $("#show_pass");
        show_pass_btn.on('click',function(evant){
            evant.preventDefault();
            if(show_pass.attr('type') == "password"){
                show_pass.attr('type','text'); 
                show_pass_btn.find('span').removeClass('fa-eye-slash');
                show_pass_btn.find('span').addClass('fa-eye');
            }else if(show_pass.attr('type') == "text"){
                show_pass.attr('type','password'); 
                show_pass_btn.find('span').removeClass('fa-eye');
                show_pass_btn.find('span').addClass('fa-eye-slash');
            }
           
        });
    });
 </script>