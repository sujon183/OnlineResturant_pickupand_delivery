<?php include("./include/owl_navigation.php"); ?>
<?php
$db_obj->select("menu","*",null,null,null,null);
$menu = $db_obj->getResult();
$menu = $menu[0];
$menu_count = count($menu);


?>
<section id="product" style="width:95%; margin:auto">
            <div class="productContainer py-5">
                <small class="font-kurale font-size-14 my-4 ">WelcomeOur &gt; Carte</small>
                <?php
              for($i=0; $i<$menu_count; $i++){
                $menu_id = $menu[$i]["menu_id"];
                $where = "menu_id = ".$menu_id;
                $db_obj->select("product","*",null,$where,null,null);
                $pro_result =$db_obj->getResult();
                $pro_result = $pro_result[0];
                $pro_count = count($pro_result);
                if($pro_count == 0){
                    break;
                }
            
            ?>
            <h1 class="font-kurale py-4 font-size-20 text-bold"><?php echo $menu[$i]["menu_name"]; ?></h1>
      
                <section id="<?php echo $menu[$i]["menu_name"]; ?>">
                    <div id="RightNow">
                        <div class="flexingRow">
                            <?php for($j=0; $j<$pro_count; $j++){ 
                                $openbtnInfo = "openbtnInfo".$pro_result[$j]["pid"];
                                $closeInfoBtn = "closeInfo".$pro_result[$j]["pid"];
                                $shortText = "shortText".$pro_result[$j]["pid"];
                                $productImages = "productImages".$pro_result[$j]["pid"];
                                
                                ?>
                        <div class="product-item">
                                <span class="fa-solid fa-info information" id="<?php echo  $openbtnInfo; ?>"></span>
                                <span class="fa-solid fa-close information display-none" id="<?php echo $closeInfoBtn; ?>" style="border: none;"></span>
                                <div class="product-desc">
                                    <p class="product-text display-none shortText" id="<?php echo $shortText;  ?>">
                                      <?php echo $pro_result[$j]["pro_des"]; ?>
                                    </p>
                                    <a href="singleProduct.php?id=<?php echo $pro_result[$j]['pid']; ?>" id="<?php  echo $productImages; ?>" ><img src="./KFC_ADMIN/assets/images/<?php echo $pro_result[$j]['pro_img']; ?>"></a>
                                </div>
                                
                                <div class="text-center d-flex flex-column bg-white shadow pt-1 pb-3">
                                    <h3 class="text-center font-rale text-black bold mb-4"><?php echo $pro_result[$j]["pro_name"]; ?></h3>
                                <a href="singleProduct.php?id=<?php echo $pro_result[$j]['pid']; ?>" class="btn color-primary-bg py-3 text-white font-size-18 mx-5">ORDER</a>
                                </div>
                        </div>
                     <?php } ?>
                        </div>
                    </div>
                </section>
                <?php } ?>

            </div>
        </section>

        