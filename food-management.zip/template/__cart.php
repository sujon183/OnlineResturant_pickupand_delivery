  <!-- main  -->
  

 
  <section id="main">
     <div class="productContainer"><div class="bars"><div></div></div></div>     
       <!-- my cart  -->
<section id="cart" class="my-5">
    <div class="productContainer py-5">
        <h2 class="font-rale cart-title">My Cart</h2>
        <!-- ORDER FORM CONFIRMATION  -->
       <form action="action/order_confirm.php" method="POST">
        <div class="row " id="loading">
        <?php 
     if(isset($_SESSION['login_user_success_abc_xyz'])){
        $user_id =  $_SESSION['login_user_success_abc_xyz']['user_id'];  
        // echo "<h1 style='margin-top:10rem;'></h1>";       
       $join = "INNER JOIN product ON cart.pid= product.pid"; 
       $where = "user_id = {$user_id}";   
       $db_obj->selectInner('cart',"*",$join, $where, null, null);
       $cart_result = $db_obj->getjoinResult();
       $cart_result = $cart_result[0];
       $total_cart_item = count($cart_result);
    //    print_r($cart_result); 
       $total_amount = (int)0;
       for($j=0; $j<$total_cart_item; $j++){
            $am = $cart_result[$j]['totalAmount'];
            $total_amount = $total_amount + (int)($am);
       }
     

 ?>

  <input hidden id="total-cart-item" value="<?php echo $total_cart_item; ?>">
            <div class="col-md-8 col-12">
                <div class="peoductList">
                     <?php for($x=0; $x<$total_cart_item; $x++){ ?>
                        <input value="<?php echo $cart_result[$x]['cid']; ?>" hidden id="<?php echo 'cart_item'.$x+1; ?>">
                    <div class="row shadow justify-content-center align-items-center">
                        <div class="col-3"><img src="./KFC_ADMIN/assets/images/<?php echo $cart_result[$x]['pro_img']; ?>" class="cart-img"></div>
                        <div class="col-6">
                            <div class="row justify-content-center align-items-center">
                                <div class="col-md-6 col-12">
                                    <h3 class="font-roboto"><?php echo $cart_result[$x]['pro_name']; ?> </h3>
                                    
                                    <?php 
                                       $op_product = $cart_result[$x]['option_pr_ids'];
                                       if($op_product != null){
                                        $op_array = explode(',',$op_product);
                                        $op_count = count($op_array);
                                     ?>
                                    <span id="<?php echo 'op_btn'.$x+1; ?>" class="pl-5 d-block font-size-16"><strong>details <span class="fa-solid fa-angle-down" onclick='details()' ></span></strong></span>
                                    <div id="<?php echo 'op_product'.$x+1; ?>" class="mb-2 display-none">
                                                <?php for($k=0; $k<$op_count; $k++){ 
                                                    $where = 'add_op_id ='.$op_array[$k];
                                                $db_obj->select('add_op_product','name',null,$where,null,null);  
                                                $op_result = $db_obj->getResult();
                                                $op_result = $op_result[0][0]['name'];
                                                
                                                ?>
                                                    
                                            <p class="font-size-14 text-black-50"><?php echo $op_result; ?></p>
                                            <?php } ?>
                                            </div>
                                            <?php } ?>
                                        <div class="d-flex my-1">
                                            <div id="<?php echo 'delete_item'.$x+1; ?>" style='cursor:pointer'>
                                                <span  class="text-danger font-size-16 my-3 px-2">Delate</span>
                                            </div>
                                            <div style='cursor:pointer'>
                                                <a href="./singleUpdate.php?id=<?php echo $cart_result[$x]['pid']; ?>" class="text-success font-size-16 my-3">Edit</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 input-group">
                                        <div class="cart-input-btn <?php echo'cart-input-btn'.$x+1; ?>" >
                                            <button  class="qty_down<?php echo $x+1; ?>"><span class="fa-solid fa-minus" ></span></button>
                                            <input name="qty[]" type="number" value="<?php echo $cart_result[$x]['quantity']; ?>" class="<?php echo 'qty_input'.$x+1; ?> text-dark" disabled placeholder="1">
                                            <button  class="qty_up<?php echo $x+1; ?>" ><span class="fa-solid fa-plus"></span></button>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="col-3">
                            <div class="price"><span class="pro_price <?php echo 'pro_price'.$x+1;  ?>"><?php echo $cart_result[$x]['totalAmount']; ?></span><span class="fa-solid fa-euro px-2"></span></div>
                        </div>
                    </div>
                    <?php } ?>
                    <?php 
                    if(isset($_SESSION['login_user_success_abc_xyz'])){
                        $user_id =  $_SESSION['login_user_success_abc_xyz']['user_id'];
                     }else{
                        $user_id="";
                     }
                        $wheresss ="WHERE user_id = ". $user_id;
                    $joins = " offer_product ON offer_cart.of_id = offer_product.of_id";
                    $db_obj->selectWhere('offer_cart',"*",$joins, $wheresss,null,null);
                    $abcd = $db_obj->whereResult();
                    $abcd = $abcd[0];
                    $count_offer_product_free = count($abcd);
                    // print_r($abcd);
                    if($count_offer_product_free !=0){
                        ?>
                        
                        <div class="row shadow justify-content-center align-items-center">
                            <div class="col-3"><img class="cart-img" src="./KFC_ADMIN/assets/images/<?php echo $abcd[0]['offer_img']; ?>"></div>
                            <div class="col-6"><h3><?php echo $abcd[0]['offer_pr_name']; ?></h3></div>
                            <div class="col-3"><h3>0 <span class="fa-solid fa-euro"></span></h3></div>
                        </div>
                        <?php
                    }
                    // ofer product ending
                    
                    ?>
                    
                </div>
            </div>

            <div class="col-12 col-md-4 shadow">
                <div class="container py-2">
                    <h1 class="font-roboto py-4"><?php echo $total_cart_item; ?> Articles</h1>
                    <hr>
                    <h2 class="font-rale promo-title">Use Promo Code</h2>
                    <div class="promoCode">
                        <input type="text" id="prom_input" class="prom_input form-control"> <br>
                        
                        <button id="promoAply" class="btn-dark apply">Apply</button>
                    </div>
                    <div class="wrongPromo my-1 text-danger font-size-20">
                        <?php
                        if(isset($_SESSION['promoMissing'])){
                            echo $_SESSION['promoMissing'];
                        }
                        ?>
                    </div>
                    <hr class="mt-5">
                    <div class="d-flex align-items-center justify-content-between py-3">
                        <h3 class="subtotal color-black-50">Subtotal</h3>
                        <h3 class="subtotal color-black-50" id="subtotal"><?php echo  $total_amount; ?> <span class="fa-solid fa-euro"></span> </h3>
                    </div>
                    <div class="d-flex align-items-center justify-content-between py-3">
                        <h3 class="totlal text-dark">Total</h3>
                        <h3 class="total text-dark" id="total"><?php
                            if(isset($_SESSION['reducedAmount'])){
                                echo $_SESSION['reducedAmount'];
                            }else{
                            echo  $total_amount;
                                }
                            ?> <span class="fa-solid fa-euro"></span>
                        </h3>
                        <input hidden type="number" id="total_id" name="totalamount" value="<?php 
                            if(isset($_SESSION['reducedAmount'])){
                                echo $_SESSION['reducedAmount'];
                            }else{
                                echo  $total_amount;
                            }
                            ?>
                        ">
                    </div>
                    <button name="order_confirm" class="color-primary-bg border-0 w-100 my-3 py-2 font-size-16 text-white">Confirm</button>
                </div>
            </div>
        </div>
        </form>
        <?php
        $sql = "SELECT amount FROM minimum_amount";
        $db_obj->sql($sql);
        $sqlREsult = $db_obj->getsqlResult();
        $sqlREsult = $sqlREsult[0][0]['amount']; 
        
        if($total_amount >= $sqlREsult){
            $db_obj->select('offer_product','*',null,null,null,null);
            $getoffer = $db_obj->getResult();
            $getoffer = $getoffer[0];
            $offer_count = count($getoffer);
            // print_r($getoffer);
            
            
            ?><?php
            if($count_offer_product_free ==0){ ?>
           <!-- // OFFER PRODUCT FORM  -->
        <form action="./action/offer_pr.php" method="post">
            <input hidden id="total_free_product" value="<?php echo $offer_count ?>">
                <input hidden name="user_id" value="<?php echo $user_id; ?>">
            <div class="row">
                <!-- CREATE TABLE offer_cart(of_cart_id int AUTO_INCREMENT,of_id int, user_id int, PRIMARY KEY(of_cart_id), FOREIGN KEY(of_id) REFERENCES offer_product(of_id), FOREIGN KEY(user_id) REFERENCES user_info(user_id) ); -->
                <?php for($m=0; $m<$offer_count; $m++){ ?>
                <div class="free_product border p-3" id="<?php echo 'free_product'.$getoffer[$m]['of_id']; ?>">
                    <input hidden id="<?php echo 'item'.$m+1; ?>" value="<?php echo $getoffer[$m]['of_id']; ?>">
                    <div class="free-product-checkbox display-none">
                        <input type="checkbox" name="add_op_checkbox[]" value="<?php echo $getoffer[$m]['of_id']; ?>">
                    </div>
                    <div class="product-desc">
                        <div class="productImages"><img src="./KFC_ADMIN/assets/images/<?php echo $getoffer[$m]['offer_img']; ?>"></div>
                    </div>
                                                
                    <div class="text-center d-flex flex-column bg-white shadow pt-1 pb-3">
                        <h3 class="text-center font-rale text-black bold mb-3 mt-2"><?php echo $getoffer[$m]['offer_pr_name']; ?></h3>
                    </div>
                </div>
                <?php } ?>
            </div>
         <div class="row my-2">
            <div class="col-4 mr-5 pr-5" style="margin-left:20rem;">
                <button type="submit" name="offer_select_btn" class="w-100 px-5 btn btn-danger" style="margin-right:10rem; font-size:1.8rem">Choose</button>
            </div>
         </div>
        </form>
            <!-- // END OFFER PRODUCT FORM  -->
        
        <?php } ?>
            <?php
        }
        ?>
   
    </div> <!--PRODUCT CONTAINER -->    
</section>
            <!-- !my cart  -->

<?php } // session close  ?>
    <!-- !main  -->

    <script id="scriptLoad">
        // Jquery start
        $(document).ready(function(){
           // qty maintance
          let total_cart_item =  $("#total-cart-item").val();
            for(let x=0; x<total_cart_item; x++){
                let cart_item_id = $("#cart_item"+(x+1)).val();
                let cart_item_input = $(".qty_input"+(x+1)).val();
                let qty_up = $(".qty_up"+(x+1));
                let qty_down = $(".qty_down"+(x+1));
                let result = $(".cart-input-btn"+(x+1));
                let singleAmount = $(".pro_price"+(x+1));
                let op_btn = $("#op_btn"+(x+1));
                let op_product = $("#op_product"+(x+1));
                let delete_item = $("#delete_item"+(x+1));
                
                // item delete method
                delete_item.click(function(){
                    let userConfirm = confirm("do you realy want to delete this item");
                    if(userConfirm == true){
                        $.ajax({
                            url:"./action/cart-item-delete.php",
                            type:'POST',
                            data:{
                                cart_item_id:cart_item_id
                            },
                            success:function(data){
                                alert("Item Has been Deleted");
                            }
                        });
                        $("#main").load('cart.php');
                    }else{
                        return false;
                    }
                });

                op_btn.click(function(){
                    op_product.toggleClass("display-none");
                }); // op product details 
                qty_up.click(function(){
                  
                    $.ajax({
                        url:'./action/qty_up.php',
                        type:'POST',
                        data:{
                            cid:cart_item_id,
                            qty:cart_item_input
                           
                        },
                        success:function(data){
                            console.log(data);
                        }
                    }); // quantity maintain
                 
                    $("#main").load('cart.php');
                    // $(".qty_input"+(x+1)).load(location.href + ".qty_input");
                    // $("#scriptLoad").load(location.href + "#scriptLoad");
                   
                }); // qty up click
                qty_down.click(function(){
                  
                    $.ajax({
                        url:'./action/qty_down.php',
                        type:'POST',
                        data:{
                            cid:cart_item_id,
                            qty:cart_item_input
                            
                        },
                        success:function(data){
                            console.log(data);
                        }
                    }); // quantity maintain
                 
                    $("#main").load('cart.php');
                    // $(".qty_input"+(x+1)).load(location.href + ".qty_input");
                    // $("#scriptLoad").load(location.href + "#scriptLoad");

                   
                }); // qty up click
                
            }

            // offer product 
           let total_free_product = $("#total_free_product").val();
            function deselect(callitem){
                for(let s=0; s<total_free_product; s++){
                    let item = $("#item"+(s+1)).val();
                    if(callitem != item){
                        let free_product = $("#free_product"+item);
                        let checkbox = free_product.find('.free-product-checkbox');
                        checkbox.find('input').prop('checked',false);
                        checkbox.addClass('display-none');
                    }
                }
            }
           for(let m=0; m<total_free_product; m++){
                let item = $("#item"+(m+1)).val();
                let free_product = $("#free_product"+item);
                free_product.click(function(){
                    let checkbox = free_product.find('.free-product-checkbox');
                    let input = checkbox.find('input');
                    let check_value = input.is(':checked');
                    if(check_value == true){
                       input.prop('checked',false);
                       checkbox.addClass('display-none');
                    }else{
                        deselect(item);
                        input.prop('checked',true);
                        checkbox.removeClass('display-none');
                    }
                
                });
           }
      

        //    promocode applying 

        $("#promoAply").click(function(){
          let promo_input = $("#prom_input").val();
          let total_amounts = $("#total_id").val();
          let wrongPromo = $(".wrongPromo");
        //   alert(total_amounts);
            $.ajax({
                url:'./action/qty_down.php',
                type:'POST',
                data:{
                    pr_input:promo_input,
                    total_amount : total_amounts
                },
                success:function(data){
                    $("#main").load('cart.php')
                }

            });
            
        });



     

        });  
        // Jquery End 
        
    </script>