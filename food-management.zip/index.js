$(document).ready(function(){
    

    // sidebar start

let $menuBar = $("#toggleMenu");
let $menuopenBtn = $("#menu");
let $menucloseBtn = $("#menuCloseIcon");



$menucloseBtn.click(function(){
    $menuBar.css("right","-50rem");
    
});


$menuopenBtn.click(function(){
    $menuBar.css("right","0");
    
});


// sidebar End 



// Owl Carousel for Carousel navigation  start
$("#owlNavigation .owl-carousel.owl-theme").owlCarousel(
    {
        dots:false,
        nav:true,
        touchDrag : false,
        mouseDrag: false,
        // autoplay:true,
        loops:false,
        responsive:{
            380:{
                items:2
            },
            770:{
                items:3
            },
            1000:{
                items:6
            }
        }
    }
); 
// Owl Carousel for Carousel navigation  End


        // product description java Script is start 

        let shortText = $(".shortText");
        let productImages = $(".productImages");
        let openInfoBtn = $(".openInfoBtn");
        let closeInfoBtn = $(".closeInfoBtn");
        
    

        // openInfoBtn.click(function(){
        //    e.innerHTML="hELLO wORLD";
        //     // $filterValue.addClass("display-none");
        //     // $filterValue.removeClass("display-none");
        //     // $filterValue.addClass("display-none");
        //     // $filterValue.removeClass("display-none");
        // });
        // closeInfoBtn.click(function(){
        //     var filterValue = $(this).attr('data-filter');
        //     filterValue.removeClass("display-none");
        //     filterValue.addClass("display-none");
        //     filterValue.removeClass("display-none");
        //     filterValue.addClass("display-none");
        // });




    // product description java Script is End 

    // login information is start 
    $myModal = $("#myModal");
    $close_btn_login_inform = $("#close_btn_login_inform");
    $userLgoin_open = $("#userLgoin_open");
    
    $userLgoin_open.click(function(){
        $myModal.css("right",'0');
    })

    $close_btn_login_inform.click(function(){
        $myModal.css("right","-100rem");
    });


    // card page quantity of product 

    // let $qty_up = $('.qty_up');
    // let $qty_down = $('.qty_down');
    
    // // click on qty up button 
    // $qty_up.click(function(e){
    //     let $input = $(`.qty_input[data-id='${$(this).data("id")}']`);
    //     if($input.val()>=1 && $input.val()<=100){
    //         $input.val(function(i, oldval){
    //             return ++oldval;
    //         });
    //     }
       
    // });

    // // click qty down button 

    // $qty_down.click(function(e){

    //     let $input = $(`.qty_input[data-id='${$(this).data("id")}']`);
    //     if($input.val()<=100 && $input.val()>1){
    //         $input.val(function(i,oldval){
    //             return --oldval;
    //         });
    //     }
    //     // alert("Hello Bangladesh");
    // });


// product text show 
let $pid_last_item = $("#pid_last_item");
$x = $pid_last_item.val();
    for(let i=1; i<=$x; i++){
      let $openInfoBtn_name = "openInfoBtn"+i;
      let $closeInfoBtn_name = "closeInfoBtn"+i;
      let $shortText_name = "shortText"+i;
      let $productImages_name = "productImages"+i;

       let $openInfoBtn = $(`#${$openInfoBtn_name}`);
       let $closeInfoBtn = $(`#${$closeInfoBtn_name}`);
       let $shortText = $(`#${$shortText_name}`);
       let $productImages = $(`#${$productImages_name}`);

        // click openbtn 
        $openInfoBtn.click(function(){
           $productImages.addClass("display-none");
           $shortText.removeClass("display-none");
           $openInfoBtn.addClass("display-none");
           $closeInfoBtn.removeClass("display-none");
        })
        // click close btn ?
        $closeInfoBtn.click(function(){
           $shortText.addClass("display-none");
           $productImages.removeClass("display-none");
           $closeInfoBtn.addClass("display-none");
           $openInfoBtn.removeClass("display-none");
        })
    // console.log($openInfoBtn_name);
    }





});



