<?php
session_start();
include("./KFC_ADMIN/database/database.php");
include("./include/header.php");
if(isset($_SESSION['login_user_success_abc_xyz'])){
$user_in = $_SESSION['login_user_success_abc_xyz'];

?>
<section id="user_info" style="margin-top:20rem;">
 <div class="container">
 <div class="row justify-content-space-between">
        <div class="col-4 bg-dark text-white py-2">
           <div class="d-flex flex-column justify-content-center align-items-center">
            <?php 
            $db_obj->select('top_logo',"*",null,null,null,null);
            $logo = $db_obj->getResult();
            $logo = $logo[0][0];
            
            ?>
          <div style="width:10rem"class="pt-3 pb-5">
                <a href="index.php" class="brand"><img style="width:100%" src="./KFC_ADMIN/assets/logo/<?php echo $logo['top_logo_name']; ?>"></a>
            </div>
            <h2 class="text-center"><span class="fa-solid fa-user border rounded-circle p-2 mx-2"></span><?php echo $user_in['user_name']; ?></h2>
           
           </div>
        </div>
    </div>
 </div>
</section>





<?php
include("./include/footer.php");
}else{
    header("locaton: login.php");
}

?>