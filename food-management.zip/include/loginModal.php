<div class="mymodal" id="usermodal">
        <div class="row justify-content-end">
            <div class="col-md-4 col-12">
               <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between"> 
                        <h3 class="font-size-20  p-2">Md Salman Ahmed</h3>
                        <h3 class=" font-size-20  p-2" id="close_btn_login_inform"><span class="fa-solid fa-xmark"></span></h3>
                    </div>
                </div>
                      <div class="card-body p-2">
                            <div class="row justify-content-center">
                                <div class="user-img ">
                                    <img src="assets/user/user2.png" alt="">
                                </div>
                            </div>
                      </div> 
                      <div class="card-footer p-2">
                       <div class="d-flex justify-content-between align-items-center">
                            <div class="user_login">
                                <a href="signup.php" class="font-size-18">Sign up</a>
                            </div>
                            <h3>I Already have an Account</h3>
                            <div class="user_register">
                                <a href="login.php" class="font-size-18">Login</a>
                            </div>
                       </div>
                      </div>
                    
                   <div class="card-footer">

                   </div>
               </div>
            </div>
        </div>
    </div>
