<section id="toggleMenu">
       <div id="navigated">
        <div class="closeIcon">
            <div class="blank"></div>
            <div class="Bars">
               
                <div></div>
            </div>
            <div class="mycloseIcon" id="menuCloseIcon"><span class="fa-solid fa-xmark"></span></div>
        </div>
       </div>
        <div class="allTogglesMenu">
            <!-- tag menu names  -->
        <div class="tagsmenu border-bottom-black-50">
            <h3> Our Menu</h3>
            <ul>
                <li><a href="#" class="mx-5">At The Moment <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Chickens & buckets <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Burgers <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Wraps & salads <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Children's menu <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">small pleasures <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Single products <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Coffees & drinks <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Desserts <span class="fa-solid fa-greater-than px-3"></span></a></li>
            </ul>
        </div>
        <!-- OUR ENTERPRISE -->
        <div class="tagsmenu border-bottom-black-50">
            <h3> OUR ENTERPRISE  </h3>
            <ul>
                <li><a href="#" class="mx-5">Our engagements<span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Chickens <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Quality <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Teams <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Planet <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Join us <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Who are we <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Our history <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Press area <span class="fa-solid fa-greater-than px-3"></span></a></li>
            </ul>
        </div>
        <!-- CONSUMER SERVICE -->
        <div class="tagsmenu border-bottom-black-50">
            <h3> CONSUMER SERVICE  </h3>
            <ul>
                <li><a href="#" class="mx-5">Contact us<span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Give your opinion <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">FAQs <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Allergen information <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Informations nutri score <span class="fa-solid fa-greater-than px-3"></span></a></li>
            </ul>
        </div>
        
         <!-- NOS SERVICES -->
         <div class="tagsmenu border-bottom-black-50">
            <h3> NOS SERVICES  </h3>
            <ul>
                <li><a href="#" class="mx-5">Click and Collect<span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Colonel Club KFC <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">KFC ORIGINS <span class="fa-solid fa-greater-than px-3"></span></a></li>
            </ul>
        </div>
         <!-- LEGAL INFORMATION -->
         <div class="tagsmenu border-bottom-black-50">
            <h3> NOS SERVICES  </h3>
            <ul>
                <li><a href="#" class="mx-5">Legal Notice<span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">CGU Click & Collect <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Loyalty Terms <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Terms of the offer <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Protection of personal data <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">KFC Global <span class="fa-solid fa-greater-than px-3"></span></a></li>
                <li><a href="#" class="mx-5">Yum cookies and ads policy <span class="fa-solid fa-greater-than px-3"></span></a></li>
            </ul>
        </div>
        
        <!-- footer of toggle menu  -->
        <section class="toggleMenufoter bg-dark px-3">
            <h3 class="text-center text-white font-kurale">FOLLOW US HERE</h3>
            <div class="socail-icon">
                <div class="circle">
                    <span class="fa-brands fa-facebook"></span>
                </div>
                <div class="circle">
                    <span class="fa-brands fa-instagram"></span>
                </div>
                <div class="circle">
                    <span class="fa-brands fa-twitter"></span>
                </div>
                <div class="circle">
                    <span class="fa-brands fa-youtube"></span>
                </div>
                <div class="circle">
                    <span class="fa-brands fa-linkedin"></span>
                </div>
            </div>
            <h3 class="font-kurale text-center text-white py-5 font-size-16">
                FOR YOUR HEALTH,  PRACTICE REGULAR <br> PHYSICAL ACTIVITY <br> WWW.MANGERBOUGER.FR
            </h3>
            <hr class="color-white-50-bg my-5">
            <h3 class="text-center text-white font-rale py-5 px-2 font-size-16">©2022 KFC France. All rights reserved.</h3>
        </section>
        
        <div class="closeIcon bg-dark">
            <div class="blank"></div>
            <div class="Bars">
               
                <div></div>
            </div>
            <div class="mycloseIcon"><span class=""></span></div>
        </div>
        </div>
        
    </section>