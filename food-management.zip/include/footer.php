   <!-- footer  -->
   <section id="footer" class="bg-dark text-white py-5">
        <div class="Cmcontainer">
            <div class="row">
                <div class="col-md-6 col-12">
                    <div class="row">
                        <div class="col-md-4 col-12">
                            <h3 class="response-for-footer text-uppercase py-3">Our menu</h3>
                            <ul class="list-style-none font-size-16 text-white">
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">At the moment</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Chickens & buckets</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Burgers</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Wraps & salads</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Children's menu</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">small pleasures</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Single products</a></li>
                            </ul>
                        </div>
                        <div class="col-md-4 col-12">
                            <h3 class="response-for-footer text-uppercase py-3">Our menu</h3>
                            <ul class="list-style-none font-size-16 text-white">
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">At the moment</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Chickens & buckets</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Burgers</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Wraps & salads</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Children's menu</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">small pleasures</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Single products</a></li>
                            </ul>
                        </div>
                        <div class="col-12 col-md-4">
                            <h3 class="response-for-footer text-uppercase py-3">Our menu</h3>
                            <ul class="list-style-none font-size-16 text-white">
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">At the moment</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Chickens & buckets</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Burgers</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Wraps & salads</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Children's menu</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">small pleasures</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Single products</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-12">
                    <div class="row">
                        <div class="col-md-4 col-12">
                            <h3 class="response-for-footer text-uppercase py-3">Our menu</h3>
                            <ul class="list-style-none font-size-16 text-white">
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">At the moment</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Chickens & buckets</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Burgers</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Wraps & salads</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Children's menu</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">small pleasures</a></li>
                                <li><a class="font-size-12 font-family-kurale text-white-50" href="#">Single products</a></li>
                            </ul>
                        </div>
                        <div class="col-12 col-md-8 border-left">
                            <section class="toggleMenufoter bg-dark px-3">
                                <h3 class="response-for-footer text-white font-kurale">FOLLOW US HERE</h3>
                                <div class="socail-icon d-flex justify-content-between">
                                    <div class="circle">
                                        <span class="fa-brands fa-facebook"></span>
                                    </div>
                                    <div class="circle">
                                        <span class="fa-brands fa-instagram"></span>
                                    </div>
                                    <div class="circle">
                                        <span class="fa-brands fa-twitter"></span>
                                    </div>
                                    <div class="circle">
                                        <span class="fa-brands fa-youtube"></span>
                                    </div>
                                    <div class="circle">
                                        <span class="fa-brands fa-linkedin"></span>
                                    </div>
                                </div>
                                <h3 class="font-kurale text-center text-white py-5 font-size-16">
                                    FOR YOUR HEALTH,  PRACTICE REGULAR <br> PHYSICAL ACTIVITY <br> WWW.MANGERBOUGER.FR
                                </h3>
                                <hr class="color-white-50-bg my-5">
                                <h3 class="text-center text-white font-rale py-5 px-2 font-size-16">©2022 KFC France. All rights reserved.</h3>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- !footer  -->
    <script>
    $(document).ready(function(){
        // owl navigation 
        $("#owlNavigation .owl-carousel.owl-theme").owlCarousel(
           { loop:false,
            nav:true,
            dots:false,
            responsive:{
                0:{
                    items:2
                },
                600:{
                    items:3
                },
                1000:{
                    items:5
                }
            }
        }
        );

        // for sidebar

        let menuopenIcon = $("#menuopen");
        let sidebar = $("#toggleMenu");
        let usermodal = $("#usermodal");
        menuopenIcon.click(function(){
            sidebar.css('right','0');
            usermodal.css('right','-100rem');
        });
        $("#menuCloseIcon").click(function(){
            sidebar.css('right','-50rem');
        })
        $("#usermodalOpen").click(function(){
            usermodal.css('right','0');
            sidebar.css('right','-50rem');
        });
    });
</script>
  
<!-- owlcarousel js file  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!-- isotope js file  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.isotope/3.0.6/isotope.pkgd.min.js" integrity="sha512-Zq2BOxyhvnRFXu0+WE6ojpZLOU2jdnqbrM1hmVdGzyeCa1DgM3X5Q4A/Is9xA1IkbUeDd7755dNNI/PzSf2Pew==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>




</body>
</html>