<?php
$db_obj->select("product","pid",null,null,null,null);
$pro_pid = $db_obj->getResult();
$pro_pid = $pro_pid[0];
$last_value = end($pro_pid);
$last_value_pid = $last_value['pid'];
$db_obj->select("menu","*",null,null,null,null);
$menu = $db_obj->getResult();
$menu = $menu[0];
$menu_count = count($menu);


?>
    <!-- main  -->
    <section id="main">
             <!-- // Carousel Navigaton  start  -->
        <section id="owlNavigation">
           <div class="container m-auto">
                <div class="owl-carousel owl-theme m-auto">
                    <?php
                    for($i=0; $i<$menu_count; $i++){
                        $menu_id = $menu[$i]["menu_id"];
                        $where = "menu_id = ".$menu_id;
                        $db_obj->select("product","*",null,$where,null,null);
                        $pro_result =$db_obj->getResult();
                        $pro_result = $pro_result[0];
                        $pro_count = count($pro_result);
                        if($pro_count == 0){
                            break;
                        }
                    
                    ?>
                    <div class="item"><a href="#<?php echo $menu[$i]["menu_name"]; ?>"><?php echo $menu[$i]["menu_name"]; ?></a></div>
                 <?php     } ?>
                </div>
           </div>
        </section>
        <!-- // Carousel Navigaton  End -->


      