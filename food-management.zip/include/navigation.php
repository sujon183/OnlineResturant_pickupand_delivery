<header>
    <nav>
        <div class="main-menu">
            <div class="brand"><img src="./KFC_ADMIN/assets/logo/logo.png" alt=""></div>
            <ul class="menuitem">
                <li><a href="#">Our Menu</a></li>
                <li><a href="#">OUR ENGAGEMENTS</a></li>
                <li><a href="#">Find a lecarte</a></li>
            </ul>
        </div>
        <div class="users">
                <div class="user" id="usermodalOpen"><span class="fa-solid fa-user-circle"></span></div>
                <div class="user userCart"><span class="fa-solid fa-cart-shopping"></span><span class="cartNumber">0</span></div>
            
                <div class="userMenu" id="menuopen">
                    <span class="fa-solid fa-bars"></span>
                </div>
        </div>
    </nav>
</header>