    <!-- footer  -->
    <section id="footer" class="bg-dark text-white py-5">
      
    </section>
    <!-- !footer  -->
        <script>
            
// // cart quantity 
// let x =  document.querySelectorAll('[data-attr]');
// var_dump(x);

// </script>

  
<!-- <script src="index.js"></script> -->
</body>
</html>