<?php
session_start();
include("./KFC_ADMIN/database/database.php");
if(isset($_SESSION['login_user_success_abc_xyz'])){
include("./include/cart-header.php");
include("./template/__cart.php");
include("./include/cart-footer.php");
}else{
    header('location: login.php');
}


?>
<!-- ./action/order_confirm.php -->