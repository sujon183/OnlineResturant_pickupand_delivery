<?php
session_start();
include("./KFC_ADMIN/database/database.php");
include("./include/signupHeader.php");

if(isset($_POST['user_register'])){
    $name = $_POST['full_name'];
    $email = $_POST['mail'];
    $where = "WHERE user_mail = '{$email}'";
    $passWord = $_POST['pass'];
    $cpass = $_POST['cpass'];
    $passHas = sha1(md5($passWord));
     $token = bin2hex(random_bytes(10));
    
     $sql = "SELECT user_mail FROM user_info $where";
     $db_obj->sql($sql);
     $result = $db_obj->getsqlResult();
      $result = $result[0];
      $count_Result = count($result);
      $subject = "Account active Conformation";
     $msg = "<h3>Your going to open your account in kfc, click below the link
       to active your Account</h3><br> 
       <a href = 'http://localhost/kfc/action/action.php?email={$email} && token={$token}'> Click Here</a>";
   
    if(empty($name) || empty($passWord)){
        $_SESSION['msg'] = "Every Fields are Recquire to Sign Up";
    }else{
        if($passWord != $cpass){
            $_SESSION['msg'] = "Password Does not match";
        }else{
          if(strlen($passWord)<5 || strlen($name) <4){
            $_SESSION['msg'] = "Name should greter than 5 charecters or latters name should greater than 4 characters";
          }else{
            if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
               $_SESSION['msg'] = "Your Email Adress is Invalid";
            }else{
             if($count_Result == 0){
                $db_obj->insert("user_info",['user_name'=>$name, 'user_mail'=>$email,
              'user_password'=>$passHas,'user_token'=>$token]);
              $mail = mail($email,$subject,$msg);
              if($mail == true){
                $_SESSION['msg'] = "Please Checked Your Mail to active your Account";
              }
              
              return true;
             }else{
              $_SESSION['msg'] = "The Email Already Exists";
              return false;
             }
             
            }
          }
        }// password checked

    
    } // empty checked 
}


include("./template/__signup.php");
include("./include/signupFooter.php");



?>