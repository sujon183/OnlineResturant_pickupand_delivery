<?php
session_start();
include("./KFC_ADMIN/database/database.php");

if(isset($_POST['add-to-cart'])){
    $user_details = $_SESSION['login_user_success_abc_xyz'];
    // echo "<h1 style='margin-top:10rem;'>Hello</h1>";
   $user_id = $user_details['user_id'];
   $pid = $_POST['product_id'];
  $pro_price = (int)$_POST['product_price'];
   $add_op_prices =(int)0;
   if(isset($_POST['add_op_checkbox'])){
   $add_pr_id[] = $_POST['add_op_checkbox'];
   $add_pr_id = $add_pr_id[0];
   $x = count($add_pr_id);
   $add_pr_ids  = "";
    for($i=0; $i<$x; $i++){
        $where = 'add_op_id ='.$add_pr_id[$i];
        $db_obj->select("add_op_product",'price',null,$where,null,null);
        $result = $db_obj->getResult();
        $result = (int)$result[0][0]['price'];
        $add_op_prices = $add_op_prices+$result;
        $add_pr_ids .=$add_pr_id[$i].",";

       
    }
   
    $add_pr_ids  = rtrim($add_pr_ids,",");
   }else{
    $add_pr_ids = "";
   }
  $cid_amount =  $add_op_prices + $pro_price;
   $db_obj->insert('cart',['user_id'=>$user_id,'pid'=>$pid,'Amount'=>$cid_amount, 'totalAmount'=>$cid_amount,'option_pr_ids'=>$add_pr_ids]);
   $_SESSION['msg'] = "Add to cart Successful";
   if(isset($_SESSION['cccpppddd'])){
    $newAmount = 0;
    $reducedAmount = $_SESSION['reducedAmount'];
    $newAmount = ((int)$newAmount + (int)$reducedAmount + (int)$cid_amount);
    $_SESSION['reducedAmount']=$newAmount;
   }
   header("location:product.php");
}


include("./include/header.php");
include("./template/__singleProduct.php");
include("./include/footer.php");


?>

