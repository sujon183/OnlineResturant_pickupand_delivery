<?php
session_start();
include("../KFC_ADMIN/database/database.php");
if(isset($_POST['pickupIn'])){
    $pickupIn = $_POST['pickupIn'];
    $sql = "SELECT * FROM pickuppoint WHERE postal_code LIKE '%{$pickupIn}%'";
    $db_obj->sql($sql);
    $result = $db_obj->getsqlResult();
    $result = $result[0];
    $x = count($result);
    $output = "";
    if($x>0){
        $output .= "<ul style='list-style:none'>";
        for ($i=0; $i < $x; $i++) { 
           $pic_id = $result[$i]['pic_id'];
           $point_code = $result[$i]['postal_code'];
           $point_name = $result[$i]['pickup_point'];
             $point_open = $result[$i]['opening'];
            list($openHour,$openminute) = explode(':',$point_open);
           $point_close = $result[$i]['closing'];
            list($close_hour,$close_minute) = explode(':',$point_close);
            $setTimezone = date_default_timezone_set('asia/Dhaka');
              $current_time =date('h:i');
             list($current_hour,$current_minute) = explode(":",$current_time);
           
              $opening_total_minutes = ($openHour*60)+$openminute;
              $closing_total_minutes = ($close_hour*60)+$close_minute;
              $current_total_minutes = ($current_hour*60)+$current_minute;
              if(($current_total_minutes >= $opening_total_minutes) && ($closing_total_minutes >= $current_total_minutes)){
                $open = "Open";
                $class = " class='open'";
    
              }else{
                $open = "Close";
                $class = " class='close'";
              }
              
        $output .= "<li><div class='row'>"; 
          $output .= "<div".$class.">". $result[$i]['postal_code']."</div>";
          $output .= "<div>". $result[$i]['pickup_point']."</div>";
          $output .= "<div class='opening'>". $open."</div>";
          $output .= "<input value ='$pic_id' hidden class='pickupPoint_id' >";
            
        $output .= "</li>";
        }
    }else{
        $output .= "No counter Found";
    }
    
    echo $output;
}


?>