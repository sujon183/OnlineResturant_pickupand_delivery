<?php
session_start();
include("../KFC_ADMIN/database/database.php");
if(isset($_POST['cart_item_id'])) {
    $cid = $_POST['cart_item_id'];
    $wheres = "cid = ".$cid;
    $db_obj->delete('cart', $wheres);
    $user_id =  $_SESSION['login_user_success_abc_xyz']['user_id'];
    $where = "user_id = ".$user_id;
    $db_obj->select('cart','totalAmount',null,$where,null,null);
    $result = $db_obj->getResult();
    $result= $result[0];
    $x = count($result);
    $db_obj->selectInner('offer_cart','*',null,$where,null,null);
    
    $inResult = $db_obj->getjoinResult();
    $inResult = $inResult[0];
    $y = count($inResult);
    $sql = "SELECT amount FROM minimum_amount";
    $db_obj->sql($sql);
    $sqlResult = $db_obj->getsqlResult();
    $sqlResult = $sqlResult[0][0];
    $min_amount = $sqlResult['amount'];
    (int)$totalAmount = (int)0;
    if($x == 0){
        if($y !=0){
            $db_obj->delete('offer_cart',$where);
        }
    }else{
    //    print_r($result);
        for($i=0; $i<$x; $i++){
            $totalAmount = ($totalAmount + (int)$result[$i]['totalAmount']);
        }
        if($totalAmount >= $min_amount){
            return true;
        }else{
            if($y !=0){
                $db_obj->delete('offer_cart',$where);
            } 
        }
    }
    

}

?>