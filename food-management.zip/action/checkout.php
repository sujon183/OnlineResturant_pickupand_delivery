<?php
session_start();
include("../KFC_ADMIN/database/database.php");
include("temp/header.php");
include("temp/__ceckout.php");
include("temp/footer.php");


?>
    
