<?php
session_start();
include("../KFC_ADMIN/database/database.php");
if(isset($_POST['offer_select_btn'])){
    $user_id = $_POST['user_id'];
    $add_op_checkbox = $_POST['add_op_checkbox'];
    $offer_product_id = $add_op_checkbox[0];
    if(empty($user_id) || empty($offer_product_id)){
        return false;
        header("location: ../cart.php");
    }else{
        $where = 'active = active AND user_id = '.$user_id;
        $db_obj->select('offer_cart','*',null,$where,null,null);
        $result = $db_obj->getResult();
        $result = $result[0];
        $x  = count($result);
        if($x==0){
            $db_obj->insert('offer_cart',['user_id'=>$user_id,'of_id'=>$offer_product_id]);
            header("location: ../cart.php");
        }else{
            return false;
            header("location: ../cart.php");
        }
        
    }
    
}
?>