<?php
if(isset($_GET['oid'])) {
   $oid =$_GET['oid'];
    ?>

<input value="<?php echo $oid; ?>" id="order_id" hidden>
<div class="row justify-content-center">
    <div class="col-md-6 col-12">
        <div class="card">
            <div class="card-header">
                <h2 class="text-center">Hello World</h2>
            </div>
            <div class="card-body">
                <form action="../order_confirm.php" method="POST">
                    <div class="form-group my-2">
                        <label for="order type"><strong>Order Type</strong></label>
                        <select  id="ordertype" class="form-control">
                            <option value="#">Choose One</option>
                            <option value="pickupPoint">Pick Up at Near Counter</option>
                            <option value="delivery">In Delivery</option>
                        </select>
                        <div id="search" class="my-2"></div>
                         <div class="form-group">
                            <label for="Phone Number"> Your Phone Number</label>
                            <input type="number" name="phoneNumber" class="form-control">
                         </div>
                        
                         <div class="form-group my-2">
                            <button class='btn btn-success px-5' name="order_with_pickup">ORDER</button>   
                         </div>
                       
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <?php }else{
        header('location: ../product.php');
    } ?>
<script>
    $(document).ready(function(){
        // onchange function 
        $("#ordertype").change(function(){
            let ordervalue = $("#ordertype").val();
            let order_id = $('#order_id').val();
           $.ajax({
            url:'./order_type.php',
            type:'post',
            data:{
                order_type:ordervalue,
                order_id:order_id
            },
            success:function(results){
                $("#search").html(results);
            
            }
           });
          
        });

    });
</script>