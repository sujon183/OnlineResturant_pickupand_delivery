<?php
session_start();
include("../KFC_ADMIN/database/database.php");
if(isset($_POST['cid']) && isset($_POST['qty'])) {
    $cid = $_POST['cid'];
    $qty = (int)$_POST['qty'];
    $quantity = (int)($qty+1);
    $where = 'cid = '.$cid;
    $db_obj->select("cart", "Amount", null, $where, null, null);
    $result = $db_obj->getResult();
    $result = (int)$result[0][0]['Amount'];
    $amount = (int)($result * $quantity);
    $db_obj->update('cart', ['quantity'=>$quantity,'totalAmount'=>$amount], $where);
    if(isset($_SESSION['cccpppddd'])) {
        $user_id =  $_SESSION['login_user_success_abc_xyz']['user_id'];
        $wheresssss = "WHERE user_id = '$user_id'";
        $db_obj->selectWhere('cart','totalAmount',null,$wheresssss,null,null);
        $results = $db_obj->whereResult();
        $results= $results[0];
        $x = count($results);
        $totalAmount = 0;
        for($i=0; $i<$x; $i++){
            $totalAmount = $totalAmount + (int)$results[$i]['totalAmount'];
        }
        $cp_val = $_SESSION['cccpppddd']['promo_val'];
        $_SESSION['reducedAmount'] = ($totalAmount - $cp_val);
    }

}
?>
