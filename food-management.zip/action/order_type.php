<?php
session_start();
include('../KFC_ADMIN/database/database.php');
if(isset($_POST['order_type'])) {
     $orderType = $_POST['order_type'];
    $order_id = $_POST['order_id'];
    $where = "oid = ".$order_id;
   
    if($orderType == 'pickupPoint'){
    // $db_obj->update('orders', ['order_type'=>'pickuoPoint'], $where);
    $db_obj->select('pickuppoint', '*', null, null, null, null);
    $pick = $db_obj->getResult();
    $pick = $pick[0];
    $x = count($pick);
        ?>
        <div class="form-group">
            <label><strong>Enter your Post  code</strong></label>
            <input type="text" class="form-control" id="postcode" name="postcode" >
            <input type="text" hidden id="pickupPoint_id" name="pickupPoint_id">
        
         </div>
         <div id="searchResults">

         </div>
         <div class="form-group my-2">
            <label for="Pickup Time">Pickup Time</label>
            <input type="datetime-local" class="form-control" name="pickuptime">
         </div>
        <?php
}

}



?> 
<style>
    #searchResults{
        background: rgba(0, 0, 0, 0.1);
        padding: 0 5rem;
    }
    li{
        padding:0.5rem 0;
    }
    .row{
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
</style>

<script>
    $(document).ready(function(){
       $("#postcode").keyup(function(){
        let input = $(this).val();
        if(input != ""){
            $.ajax({
                url:'./searchResult.php',
                type:'post',
                data:{
                    pickupIn:input
                },
                success:function(results){
                    $("#searchResults").fadeIn();
                    $("#searchResults").html(results);
                    
                }
            });
        }else{
          $("#searchResults").fadeOut();
        }
       });

       $(document).on('click','li',function(){
        // $("#postcode").val($(this).text());
        $field = $(this).find('.open').text();
        $opening = $(this).find('.opening').text();
        $('#pickupPoint_id').val($(this).find('.pickupPoint_id').val());
        $("#postcode").val($field);
            if($opening == 'Open') {
                $("#searchResults").fadeOut();
            }
       });
    });
</script>