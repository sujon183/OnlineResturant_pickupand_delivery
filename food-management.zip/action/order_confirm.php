<?php
session_start();
include("../KFC_ADMIN/database/database.php");
if(isset($_POST['order_confirm'])){
    $user_id =  $_SESSION['login_user_success_abc_xyz']['user_id'];
$where = 'user_id = '.$user_id;
$db_obj->select('cart','*',null,$where,null,null);
$result = $db_obj->getResult();
$result = $result[0];

// print_r($result);
echo "<br>";
echo "<br>";
$x = count($result);
$product_id = "";
$product_quantity = "";
$option_products = "";
$single_amount = "";
$total_amount = 0;
$promo_code = "";
$promo_val = 0;
$promo_id;
$offer_product;
if($x>0){
  for($i=0; $i<$x; $i++){
    $product_id .= $result[$i]['pid'].",";
    $product_quantity .= $result[$i]['quantity'].",";
    $single_amount = $result[$i]['totalAmount'].",";
    $total_amount = ($total_amount + (int)$result[$i]['totalAmount']);
    $op = $result[$i]['option_pr_ids'];
      if($op == null){
        $op =0;
      }
    $option_products .= $op.".";
    if(isset($_SESSION['cccpppddd'])){
      $promo_code = $_SESSION['cccpppddd']['promoCode'];
      $promo_val = $_SESSION['cccpppddd']['promo_val'];
      $promo_id = $_SESSION['cccpppddd']['coupon_id'];
    }else{
        $promo_code = null;
        $promo_val = null;
        $promo_id = null;
    }
   
  }
}
 $sql = "SELECT of_id FROM offer_cart WHERE $where";
 $db_obj->sql($sql);
 $sqlResult = $db_obj->getsqlResult();
 $sqlResult = $sqlResult[0];
 $y = count($sqlResult);
 if($y == 1){
  $offer_product = $sqlResult[0]['of_id'];
 }else{
  $offer_product = null;
 }
  $offer_product;
 $product_id = rtrim($product_id,',');
 $product_quantity = rtrim($product_quantity,',');
  $option_products = rtrim($option_products,'.');
 $single_amount = rtrim($single_amount,',');
// echo $promo_id;
if($promo_id != null){
    if($offer_product != null){
        $order_array = ['pids'=>$product_id,'user_id'=>$user_id,'productAmount'=>$single_amount,'totalAmount'=>$total_amount,'coupon_id'=>$promo_id,'coup_code'=>$promo_code,'coupon_value'=>$promo_code,'of_id'=>$offer_product,'add_op_ids'=>$option_products];
    }else{
        $order_array = ['pids'=>$product_id,'user_id'=>$user_id,'productAmount'=>$single_amount,'totalAmount'=>$total_amount,'coupon_id'=>$promo_id,'coup_code'=>$promo_code,'coupon_value'=>$promo_code,'add_op_ids'=>$option_products];
    }
}else{
    if($offer_product != null){
        $order_array = ['pids'=>$product_id,'user_id'=>$user_id,'productAmount'=>$single_amount,'totalAmount'=>$total_amount,'of_id'=>$offer_product,'add_op_ids'=>$option_products];
    }else{
        $order_array = ['pids'=>$product_id,'user_id'=>$user_id,'productAmount'=>$single_amount,'totalAmount'=>$total_amount,'add_op_ids'=>$option_products];
    }
}

 $db_obj->insert('orders',$order_array);
 $inserted_id = $db_obj->getInsertResult();
 $inserted_id = $inserted_id[0];


    header("location:checkout.php?oid=$inserted_id");
}


?>