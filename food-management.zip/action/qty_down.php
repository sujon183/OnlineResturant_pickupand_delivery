<?php
session_start();
include("../KFC_ADMIN/database/database.php");
if(isset($_POST['cid']) && isset($_POST['qty'])) {
    $cid = $_POST['cid'];
    $qty = (int)$_POST['qty'];
    if($qty >1) {
        $quantity = (int)($qty - 1);
        $wheres = 'cid = '.$cid;

        $db_obj->select("cart", "Amount", null, $wheres, null, null);
        $result = $db_obj->getResult();
        $result = (int)$result[0][0]['Amount'];
        $amount = (int)($result * $quantity);
        $db_obj->update('cart', ['quantity'=>$quantity,'totalAmount'=>$amount], $wheres);
        
    }
    $user_id =  $_SESSION['login_user_success_abc_xyz']['user_id'];
 $wheresssss = "WHERE user_id = '$user_id'";
 $where = "user_id = '$user_id'";
$db_obj->selectWhere('cart','totalAmount',null,$wheresssss,null,null);
$results = $db_obj->whereResult();
$results= $results[0];
$x = count($results);
$db_obj->selectInner('offer_cart','*',null,$where,null,null);

$inResult = $db_obj->getjoinResult();
$inResult = $inResult[0];
$y = count($inResult);
$sql = "SELECT amount FROM minimum_amount";
$db_obj->sql($sql);
$sqlResult = $db_obj->getsqlResult();
$sqlResult = $sqlResult[0][0];
$min_amount = $sqlResult['amount'];
(int)$totalAmount = (int)0;
if($x == 0){
    if($y !=0){
        $db_obj->delete('offer_cart',$where);
    }
}else{
//    print_r($result);
    for($i=0; $i<$x; $i++){
        $totalAmount = ($totalAmount + (int)$results[$i]['totalAmount']);
        if(isset($_SESSION['cccpppddd'])){
            // reducedAmount
            $cp_val = $_SESSION['cccpppddd']['promo_val'];
            $_SESSION['reducedAmount'] = ($totalAmount - $cp_val);
        }
    }
    if($totalAmount >= $min_amount){
        return true;
    }else{
        if($y !=0){
            $db_obj->delete('offer_cart',$where);
        } 
    }
}
    
    
}





// PROMO CODE 

if(isset($_POST['pr_input']) && isset($_POST['total_amount'])){
    $promo = $_POST['pr_input'];
    $where = "coup_code = '$promo'";
    // $total_amount = (int)$_POST['total_amount'];
    $db_obj->select('coupon_master',"*",null, $where,null,null);
    $result = $db_obj->getResult();
    $result= $result[0];
    $x = count($result);
    if($x>0){
        $cp_val = $result[0]['coupon_value'];
        $cp_id = $result[0]['coupon_id'];
        $cp_start_date = strtotime($result[0]['start_time']);
        $cp_end_date = strtotime($result[0]['end_time']);
        $today = strtotime(date('Y/m/d'));
         $minAmount = $result[0]['min_amount'];
         $user_id =  $_SESSION['login_user_success_abc_xyz']['user_id'];
         $wheresssss = "WHERE user_id = '$user_id'";
         $db_obj->selectWhere('cart','totalAmount',null,$wheresssss,null,null);
         $results = $db_obj->whereResult();
         $results= $results[0];
         $y = count($results);
         $totalAmount = 0;
         if($y>0){
           for($i=0; $i<$y; $i++){
             $totalAmount = $totalAmount + (int)$results[$i]['totalAmount'];
           }
         }

            if($totalAmount >= $minAmount){
                if(($today>=$cp_start_date) && ($cp_end_date>=$today)){
                    $_SESSION['cccpppddd'] = ['promoCode'=>$promo, 'promo_val'=>$cp_val,'coupon_id'=>$cp_id];
                    $_SESSION['reducedAmount'] = ($totalAmount - (int)$cp_val);
                    $_SESSION['promoMissing'] = "Successfully Aply This Code";
                  }else{
                    $_SESSION['promoMissing'] = "Your offer is not available now";
                  }
               
            }else{
                $_SESSION['promoMissing'] = "Please Select More to Apply this Code";
             }
    }else{
        $_SESSION['promoMissing'] = "You Apply Wrong Code";
    }

}

?>