<?php
session_start();
include("./KFC_ADMIN/database/database.php");
include("./include/header.php");
include("./template/__product.php");
include("./include/footer.php");
?>

