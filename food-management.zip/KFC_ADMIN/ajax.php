<?php
include("./database/database.php");
$menu_id = $_POST['datapost'];
$where = 'menu_id='.$menu_id;
$db_obj->select("sub_menu","*",null,$where,null,null);
$result = $db_obj->getResult();
$result = $result[0];
$x = count($result);
for($i=0; $i<$x; $i++){
    ?>
    <option value="<?php echo $result[$i]['sub_menu_id']; ?>"><?php echo $result[$i]['sub_menu_name']; ?></option>
<?php } ?>