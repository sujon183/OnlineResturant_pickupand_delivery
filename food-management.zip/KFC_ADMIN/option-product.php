<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include("./database/database.php");
if(isset($_POST['op_add_btn'])){
    $type = $_POST['type'];
   $op_name = $_POST['op_name'];
   if(empty($op_name)|| empty($type)){
    $_SESSION['msg'] = "Something is Wrong";
   }else{
    $db_obj->insert('op_product',['op_name'=>$op_name,'op_type'=>$type]);
    header('location: option-product.php');
   }
}

include("./includes/header.php");
include("./template/__product_option.php");
include("./includes/footer.php");

// session end 
}else{
    $_SESSION['msg'] = "Please Login First";
    header("location: admin_login.php");
  }



?>