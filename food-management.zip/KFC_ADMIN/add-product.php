<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include('./database/database.php');
if(isset($_POST['product_up_btn'])){
   $token =  bin2hex(random_bytes(6));
   $name = $_POST['Product_Name'];
   $desc = $_POST['pr_desc'];
   $r_price = $_POST['r_price'];
   $o_price = $_POST['o_price'];
   $category = $_POST['category'];
   $pr_img = $_FILES['pr_img'];
   $pr_img_tmp = $pr_img['tmp_name'];
   $pr_img_name = $pr_img['name'];
   $img_arrray = explode('.',$pr_img_name);
   $img_ext = end($img_arrray);
   $ext = array('jpg','png','jpeg');
   $product_img = $token."_".$pr_img_name;
  
   if(isset($_POST['specialPrice'])){
       $special_pr = $_POST['specialPrice'];
   }else{
      $special_pr =0;
   }
   $dir = 'assets/images';
  if(isset($_POST['discount'])){
   $discount = $_POST['discount'];
  }else{
   $discount =0;
  }
if(isset($_POST['sliderImgCheckbtn'])){
  $slider_img = $_FILES['sliderImages'];
  $slider_img_tmp = $slider_img['tmp_name'];
  $slider_img_name = $slider_img['name'];
  $sl_array = explode('.',$slider_img_name);
  $slider_ext =end($sl_array);
  $up_slider_img = $token."_".$slider_img_name;
  
}else{
   $slider_img ="";
   $up_slider_img = "";
}
 if(isset($_POST['op_product'])){
    $x[] = $_POST['op_product'];
    $x = $x[0];
// print_r($x);
 $y = count($x);

 $op_id="";
 for($i=0; $i<$y; $i++){
   $op_id .= $x[$i].',';
 }
 $op_ids = rtrim($op_id,',');
 }else{
   $op_ids="";
 }


 if(empty($name) || empty($desc) || empty($r_price) || empty($category)|| empty( $pr_img)){
   $_SESSION['msg'] = "Something is wrong , Please check your input";
 }else{
   if(in_array($img_ext,$ext)){
      if($slider_img != ""){
         if(in_array($slider_ext,$ext)){
            move_uploaded_file($slider_img_tmp, "$dir/$up_slider_img");
            move_uploaded_file($pr_img_tmp,"$dir/$product_img");
            if(isset($_POST['subCategory'])){
              $subCategory = $_POST['subCategory']; 
            $db_obj->insert('product',['pro_name'=>$name, 'pro_desc'=>$desc, 'pro_regular_price'=>$r_price, 'pro_offer_price'=>$o_price,
         'menu_id'=>$category, 'sub_menu_id '=>$subCategory, 'pro_img'=>$product_img, 'special_price'=>$special_pr,
         'slider_img'=>$up_slider_img, 'discount'=>$discount, 'option_pro_id'=>$op_ids]);
            }else{
               $db_obj->insert('product',['pro_name'=>$name, 'pro_desc'=>$desc, 'pro_regular_price'=>$r_price, 'pro_offer_price'=>$o_price,
         'menu_id'=>$category,'pro_img'=>$product_img, 'special_price'=>$special_pr,
         'slider_img'=>$up_slider_img, 'discount'=>$discount, 'option_pro_id'=>$op_ids]); 
            }
            
            header('location: product.php');
         }else{
            $_SESSION['msg'] = 'the slider image should image file';
         }
         
      }else{
         move_uploaded_file($pr_img_tmp,"$dir/$product_img");
         if(isset($_POST['subCategory'])){
            $subCategory = $_POST['subCategory']; 
         $db_obj->insert('product',['pro_name'=>$name, 'pro_desc'=>$desc, 'pro_regular_price'=>$r_price, 'pro_offer_price'=>$o_price,
      'menu_id'=>$category, 'sub_menu_id '=>$subCategory, 'pro_img'=>$product_img, 'special_price'=>$special_pr,
      'discount'=>$discount, 'option_pro_id'=>$op_ids]);
         }else{
            $db_obj->insert('product',['pro_name'=>$name, 'pro_desc'=>$desc, 'pro_regular_price'=>$r_price, 'pro_offer_price'=>$o_price,
            'menu_id'=>$category,'pro_img'=>$product_img, 'special_price'=>$special_pr,
            'discount'=>$discount, 'option_pro_id'=>$op_ids]); 
         }
      header('location: product.php');
      }

   }else{
      $_SESSION['msg'] = "Please Upload a Image file";
   }
 }


 

}








include('./includes/header.php');
include('./template/__add_product.php');
include('./includes/footer.php');

// session end 
}else{
   $_SESSION['msg'] = "Please Login First";
   header("location: admin_login.php");
 }


?>