<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include("./database/database.php");

if(isset($_POST['add_sub_menu'])){
    $sub_name = $_POST['sub_name'];
    $menu_id = $_POST['main-menu'];

    if(empty($sub_name) || empty($menu_id)){
        $_SESSION['msg'] = "Something is Wrong";
    }else{
        $db_obj->insert('sub_menu',['sub_menu_name'=>$sub_name,'menu_id'=>$menu_id]);
        header("location: sub-menu.php");
    }
}


include("./includes/header.php");
include("./template/__add_sub_menu.php");
include("./includes/footer.php");


// session end 
}else{
    $_SESSION['msg'] = "Please Login First";
    header("location: admin_login.php");
  }










?>