<?php 
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
 include("./template/__reprot.php"); 

//  session end 
}else{
    $_SESSION['msg'] = "Please Login First";
    header("location: admin_login.php");
  }
 
 ?>