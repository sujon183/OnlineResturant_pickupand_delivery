<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include("./database/database.php");
include("./includes/header.php");
include("./template/__update_coupon.php");
include("./includes/footer.php");

// session end 
}else{
    $_SESSION['msg'] = "Please Login First";
    header("location: admin_login.php");
  }

?>