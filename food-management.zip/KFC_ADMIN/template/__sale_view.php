

<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
   <Section id="main">
      
        <section id="offerProducts" class="py-3 mx-3">
            <div class="card">
                <div class="card-header">
                    <div class=" background-color px-3">
                        <div class="post_info "><span class="fa-solid fa-table font-size-18 px-2"></span><h3>All Post Information</h3></div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center  px-3 py-2 color-white-bg">
                       
                        <div class="form-container">
                            <h3>
                                <form action="#">
                                    <span class="px-2">Show</span><select name="" id="">
                                        <option value="10">10</option>
                                        <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                    <span class="px-2">Entries</span>
                                </form>
                            </h3>
                        </div>
                        <div class="form-container">
                            <h3>
                                <form action="#" class="border d-flex align-items-center">
                                  <input type="text" class="border-0 search_input font-size-16 px-2">
                                  <button class="btn"><span class="fa-solid fa-search font-size-16"></span></button>
                                </form>
                            </h3>
                        </div>
                    
                    </div>
                      <table class="table table-striped table-hover my-3 text-center">
                    <thead class="color-white-50-bg font-size-16 font-playfair">
                        <tr>
                           <th>No.</th>
                           <th>Name</th>
                           <th>Limit Buy</th>
                           <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-16">
                        <tr>
                            <td>1</td>
                            <td>Afreen</td>
                            <td> 2</td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="" class="px-1">
                                        <input type="text" value="1" hidden>
                                        <button type="submit" class="font-size-16 btn btn-dark">Add</button>
                                    </form>
                                    <a href="#" class="text-white "><span class="fa fa-outdent px-3 py-2 color-primary-bg mt-1"></span></a>
                               </div>
                            </td>
                       </tr>
                        <tr>
                            <td>1</td>
                            <td>Afreen</td>
                            <td> 2</td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="" class="px-1">
                                        <input type="text" value="1" hidden>
                                        <button type="submit" class="font-size-16 btn btn-dark">Add</button>
                                    </form>
                                    <a href="#" class="text-white "><span class="fa fa-outdent px-3 py-2 color-primary-bg mt-1"></span></a>
                               </div>
                            </td>
                       </tr>
                        <tr>
                            <td>1</td>
                            <td>Afreen</td>
                            <td> 2</td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="" class="px-1">
                                        <input type="text" value="1" hidden>
                                        <button type="submit" class="font-size-16 btn btn-dark">Add</button>
                                    </form>
                                    <a href="#" class="text-white "><span class="fa fa-outdent px-3 py-2 color-primary-bg mt-1"></span></a>
                               </div>
                            </td>
                       </tr>
                     
                    </tbody>
                 </table>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="font-size-16">Showing 1 to 4 items of 4 Entries</p>
                        <nav aria-label="Page navigation example" class="mypagination">
                            <ul class="pagination">
                              <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                  <span aria-hidden="true">&laquo;</span>
                                </a>
                              </li>
                              <li class="page-item"><a class="page-link" href="#">1</a></li>
                              <li class="page-item"><a class="page-link" href="#">2</a></li>
                              <li class="page-item"><a class="page-link" href="#">3</a></li>
                              <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                  <span aria-hidden="true">&raquo;</span>
                                </a>
                              </li>
                            </ul>
                          </nav>
                    </div>
                </div>
            </div>
        </section>
   </Section>
