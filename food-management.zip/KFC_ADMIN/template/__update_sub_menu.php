<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
<Section id="main">
      <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <div class="card py-5 px-5">
                    <h2 class="card-header  color-secondary font-size-20">Update Sub Menu </h2>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-containeer">
                                    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                                        <div class="form-group">
                                            <select name="main-menu" id="" class="form-control font-size-18">
                                                <option value="*">Select a Menu</option>
                                                <?php       
                                                $db_obj->select('menu','*',null, null, null,null);

                                                $result = $db_obj->getResult();
                                                $result =$result[0];
                                                $x = count($result);
                                                for($i=0; $i<$x; $i++){   ?>
  
                                                <option value="<?php echo $result[$i]['menu_id']; ?>"><?php echo $result[$i]['menu_name']; ?></option>
                                                <?php   }
                                                ?>
                                            </select>
                                        </div>
                                        <?php
                                        if(isset($_POST['up_sub_menu_btn'])){
                                            $sub_menu_id = $_POST["sub_menu_id"];
                                            $page = $_POST["page"];
                                            $sql = "SELECT * FROM sub_menu where sub_menu_id =".$sub_menu_id;
                                            $db_obj->sql($sql);
                                            $getsqlResult = $db_obj->getsqlResult();
                                            $getsqlResult = $getsqlResult[0][0];
                                            $valu_sub_menu =  $getsqlResult['sub_menu_name'];
                                            $sub_menu_id =  $getsqlResult['sub_menu_id'];
                                            
                                            




                                        ?>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18">Sub Menu</label>
                                            <input type="text" class="form-control font-size-18  border-0 bg-light" value="<?php echo $valu_sub_menu; ?>" name="sub_name">
                                        </div>
                                        <input type="text" value="<?php echo $page; ?>" hidden name="page">
                                        <input type="text" hidden value='<?php echo $sub_menu_id; ?>' name="sub_menu_id">

                                        <div class="form-group my-5">
                    <?php } ?>               
                                            <input type="submit" name="add_sub_menu" class="form-control font-size-18  btn btn-success" value="Add">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      </div>
   </Section>

  
