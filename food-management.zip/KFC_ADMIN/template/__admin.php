<div class="container">
    <div class="card py-3 my-3">
        <h1 class="card-header">Admin Profile</h1>
        <div class="card-body">
            <div class="row justify-content-between my-3">
                <div class="col-12 col-md-5">
                  <h3>Cange User Name</h3>
                    <form action="admin_ac.php" method="post">
                        <div class="form-gorup font-size-18">
                            <input type="text" class="form-control font-size-18">
                        </div>
                        <div class="form-group my-3">
                            <button name="ad_ser_ch_btn" class=" font-size-18 text-white btn form-control color-primary-bg" type="submit">Update</button>
                        </div>
                    </form>
                </div>
                <div class="col-12 col-md-5">
                  <h3>Cange User Password</h3>
                    <form action="admin_ac.php" method="post">
                        <div class="form-gorup font-size-18">
                            <input type="password" class="form-control font-size-18">
                        </div>
                        <div class="form-group my-3">
                            <input type="submit" value="Update" name="ad_pass_ch_btn" class=" font-size-18 text-white btn form-control color-primary-bg">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>