<?php 

    
if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page =1;
}

$db_obj->select('offer_product',"*",null, null, null, 4,1);
$result =  $db_obj->getResult();
$result =$result[0];
$x = count($result);



        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
   <Section id="main">
    <div id="mymodal" class="mymodal py-5 w-100">
        <div class="row justify-content-center">
          <div class="col-12 col-md-5">
              <div class="card">
                  <div class="card-header">
                      <div class="d-flex justify-content-between">
                           <h1 class="color-primary">Add  </h1>
                           <h1 class="color-primary" id="Add_product_close_btn"><span class="fa-solid fa-xmark"></span></h1>
                      </div>
                     
                      
                  </div>
                  
                  <div class="card-body">
                      <div class="form-container">
                          <form action="./action/action.php" enctype="multipart/form-data" method="POST">
                              <div class="form-group my-4 font-size-18">
                                  <label>Name</label>
                                  <input type="text" class="form-control font-size-20" name="name">
                              </div>
                              <div class="form-group my-4 font-size-20">
                                  <label>Product Image</label>
                                  <input type="file" class="form-control font-size-18" name="offer_img">
                                 
                              </div>
                              <div class="form-group my-5 font-size-18">
                                 
                                  <input type="submit" name="offer_pr_up_btn" class="form-control btn color-primary-bg text-white report_btn font-size-20" value="Add">
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div> 
             
        </div>
      </div>
        <div class="row justify-content-center py-3">
            <div class="col-4">
                <div class="card pb-3">
                    <h2 class="font-size-20 my-5 text-center card-title">Set Offer Minimum Amount (<span class="fa-solid fa-euro"></span>)</h2>
                    <div class="card-body">
                        <div class="form-container">
                        <form action="./action/action.php" method="POST">
                            <div class="d-flex">
                               <input hidden value="<?php echo $page; ?>" name="page">
                                <input type="number" name="amount" class="form-control mx-3 font-size-18" value="100">
                                <button name="min_amount_btn" class="btn color-btn-bg  font-size-18 report_btn">Submit</button>
                               
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section id="offerProducts" class="py-3 mx-3">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center background-color px-3">
                        <div class="post_info "><span class="fa-solid fa-table font-size-18 px-2"></span><h3>All Post Information</h3></div>
                        <div class="add_offer"> <a href="#" class="btn color-primary-bg report_btn font-size-18" id="Add_product_open_btn">Add</a></div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center  px-3 py-2 color-white-bg">
                       
                        <div class="form-container">
                            <h3>
                                <form action="#">
                                    <span class="px-2">Show</span><select name="" id="">
                                        <option value="10">10</option>
                                        <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                    <span class="px-2">Entries</span>
                                </form>
                            </h3>
                        </div>
                        <div class="form-container">
                            <h3>
                                <form action="#" class="border d-flex align-items-center">
                                  <input type="text" class="border-0 search_input font-size-16 px-2">
                                  <button class="btn"><span class="fa-solid fa-search font-size-16"></span></button>
                                </form>
                            </h3>
                        </div>
                    
                    </div>
                      <table class="table table-striped table-hover my-3">
                    <thead class="color-white-50-bg font-size-20 font-playfair">
                        <tr>
                           <th>NO.</th>
                           <th>NAME</th>
                           <th>Image</th>
                           <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                        <?php 
                        for($i =0; $i<$x; $i++){ ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $result[$i]['offer_pr_name']; ?></td>
                            <td><img src="assets/images/<?php echo $result[$i]['offer_img']; ?>" class="product_images"></td>
                            <td>
                                <form action="./action/action.php" method="POST">
                                    <input name="of_id" hidden value="<?php echo $result[$i]['of_id']; ?>">
                                    <button class="btn btn-danger font-size-16" name="offer_pr_dlt_btn">Delete</button>
                                </form>
                            </td>
                        </tr>
                       <?php  } ?>
                    </tbody>
                 </table>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="font-size-16">Showing 1 to 4 items of 4 Entries</p>
                        <nav aria-label="Page navigation example" class="mypagination">
                            <?php echo $db_obj->pagination('offer_product',null,null,4,1); ?>
                          </nav>
                    </div>
                </div>
            </div>
        </section>
       
   </Section>