
<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
 <section id="main" class="py-3">
    <div class="container">
        <h1 class="font-playfair  color-primary font-size-20 text-uppercase page-title">Complete Order</h1>
        <div class="row my-5">
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4 my-3">
                <div class="card p-2">
                    <div class="card-header color-primary-bg">
                        <h3 class="text-center text-white  py-2">Order No. 10</h3>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Order Type</div>
                            <div><button class="btn btn-success font-size-16">Delivar<br>10:30:20</button></div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Name</div>
                            <div class="font-size-16">Salman Ahmed</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Phone</div>
                            <div class="font-size-16">+8801580615042</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Address</div>
                            <div class="font-size-16">Magura, Mohhammadpur</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">City</div>
                            <div class="font-size-16">Khulna</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Type</div>
                            <div class="font-size-16">Cash</div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Payment Status</div>
                            <div class="font-size-16">Pending</div>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="font-size-16">Total</div>
                            <div class="font-size-16">60<span class="fa-solid fa-euro"></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 </section>


