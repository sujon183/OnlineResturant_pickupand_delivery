<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
<?php  unset($_SESSION['msg']);  } ?>
<Section id="main">
      <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <div class="card py-5 px-5">
                    <h2 class="card-header  color-secondary font-size-20">Add Coupon  </h2>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-containeer">
                                    <form action="./form_recurtion/coupon-master-ac.php" method="post">
                                        <div class="form-group">
                                            <label  class="font-size-18">Coupon Code</label>
                                            <input type="text" name="coupon_name" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18">Coupon Value</label>
                                            <input type="number" name="coupon_value" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18">Minimum Amount</label>
                                            <input type="numbe" name="min_amount" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18"  >Start Date</label>
                                            <input type="date" name="strt_date" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18">End Date</label>
                                            <input type="date" name="end_date" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-5">
                                          
                                            <input type="submit" name="add_coupon_btn" class="form-control font-size-18  btn btn-success" value="Add">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      </div>
   </Section>

  
