<?php 
 $db_obj->select('menu',"*",null,null,null,"2");

$result = $db_obj->getResult();
$result = $result[0];
$x = count($result);

$pagination = $db_obj->pagination("menu",null,null,"2");
// print_r($pagination);

?>

<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
        <!-- total order with select time  -->
    <div class="container">
         <div class="row justify-content-center my-5">
        <div class="col-12">
           
                <h1 class="font-playfair  text-capitalize color-primary mb-5 report-table-title "> 
                    <a href="add_menu.php">Add Menu</a>
                </h1>
                <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>SI. NO.</th>
                            <th>MENU</th>
                            <th>IMAGE</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                        <?php
                        for($i = 0; $i<$x; $i++){

                       
                        ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $result[$i]['menu_name']; ?></td>
                            <td><img src="assets/images/<?php echo $result[$i]['menu_img']; ?>" alt="" class="product_images"></td>
                            <td>
                                <div class="d-flex justify-content-center">

                           
                                    <form action="./action/action.php" class="px-1" method="POST">
                                       
                                        <?php
                                        
                                        $y =  $result[$i]['active'];
                                        $ac_btn="";
                                        if($y == 0){
                                          $ac_btn = "Deactive";
                                          $cls = "btn-danger";
                                        }else{
                                          $ac_btn = "Active";
                                          $cls = "btn-success";
                                        }
                                       
                                        if(isset($_GET['page'])){
                                          $page = $_GET['page'];
                                        }else{
                                          $page = 1;
                                        }
                                        
                                        ?>
                                        <input type="text" hidden name="url" value="<?php echo $page; ?>">
                                         <input type="text" value="<?php echo $result[$i]['menu_id']; ?>" hidden name="active_id">
                                        <button type="submit" name="menu_active_btn" 
                                        class="font-size-16 btn <?php echo $cls ?>"><?php echo $ac_btn ?></button>
                                    </form>
                                    <a href="./update_menu.php?id=<?php echo $result[$i]['menu_id']; ?>" class="btn btn-warning font-size-16 mx-2">Update</a>
                                   <form action="./action/action.php" method="POST">
                                   <input type="text" value="<?php echo $result[$i]['menu_id']; ?>" hidden name="delete_id">
                                   <button type="submit"  class="btn btn-danger font-size-16 " name="menu_delete_btn">Delete</button>
                                   </form>
                               </div>
                          </td>
                        </tr>
                     <?php  } ?>
                    </tbody>
                 </table>
                 <nav aria-label="Page navigation example" class="mypagination">
                    <?php echo $pagination; ?>
                  </nav>
            
        </div>
     </div>
 
    </div>
  </section>
  