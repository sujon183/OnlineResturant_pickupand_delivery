<?php 
$db_obj->select('op_product',"*",null,null,null,null);
$result = $db_obj->getResult();
$result = $result[0];
$x = count($result);
$sql = "SELECT * FROM menu";
$db_obj->sql($sql);
$sqlResult = $db_obj->getsqlResult();
$sqlResult = $sqlResult[0];
$y = count($sqlResult);

?>
 <?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
<Section id="main">
      <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <h1 class="card-header  color-secondary font-size-20">Add Product  </h1>
                    <div class="card-body">
                        <form action="<?php $_SERVER['PHP_SELF']; ?>" class="font-size-20" method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-8 col-12">
                                <div class="form-container">
                                    
                                        <div class="form-group my-2">
                                            <label>Product Name</label>
                                            <input type="text" class="form-control font-size-18" required name="Product_Name">
                                        </div>
                                        <div class="form-group my-2">
                                            <label>Product Description</label>
                                            <textarea name="pr_desc" id="" cols="30" rows="10" class="form-control font-size-18 resize-none"></textarea>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Regular Price</label>
                                                    <input type="number" name="r_price" class="form-control font-size-18" placeholder="200">
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Offer Price</label>
                                                    <input type="number" name="o_price" class="form-control font-size-18" placeholder="200">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Category</label>
                                                    <select name="category" onchange="getSubcategory(this.value )"  class="form-control font-size-18">
                                                        <option value="" >Select acategory</option>
                                                       <?php
                                                       for($i=0; $i<$y; $i++){ ?>
                                                       <option value="<?php echo $sqlResult[$i]['menu_id']; ?>"><?php echo $sqlResult[$i]['menu_name']; ?></option>
                                                    <?php }  ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Sub Category</label>
                                                    <select name="subCategory" id="subCategory" class="form-control font-size-18">
                                                        <option value="*" >Select a sub category</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group my-2">
                                            <label>Product Image</label>
                                            <input type="file" name="pr_img" class="form-control font-size-18">
                                        </div>
                                    
                                </div>
                            </div>
                            <div class="col-md-4 col-12 border my-2">
                                <div class="row">
                                    <div class="col-6 my-2">
                                        <h3>Special Price</h3>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" class="form-check-input" name="specialPrice" value="1">
                                        </div>
                                    </div>
                                    <div class="col-6 my-2">
                                        <h3>Product for Slider</h3>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" name="sliderImgCheckbtn" class="form-check-input" id="sliderImgBtn" onclick="sliderimgshoe()">
                                        </div>
                                    </div>
                                    <div class="col-6 my-2">
                                        <h3>Not Discountable</h3>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" class="form-check-input" name="discount">
                                        </div>
                                    </div>
                                </div>
                                <div class="row display-none" id="sliderDIv">
                                    <div class="col-12 font-size-18 my-2">
                                        <input type="file" name="sliderImages" class="form-control font-size-18">
                                    </div>
                                </div>
                                <div class="row">
                                    <h3 class="py-3">Product Option </h3>
                                    <?php 
                                        for($i=0; $i<$x; $i++){

                                      ?>
                                    <div class="col-6 my-1">
                                        <div class="d-flex justify-content-around ">
                                            <input type="checkbox" class="form-check" name="op_product[]" value="<?php echo $result[$i]['op_id']; ?>">
                                            <label class="form-check-label font-size-16 align-items-center"><?php echo $result[$i]['op_name']; ?> </label>
                                        </div>
                                    </div>
                                    <?php } ?>
                                  
                                </div>
                            </div>
                        </div>
                        <div class="form-group my-4">
                            <button class="w-100 btn color-primary-bg text-white report_btn font-size-20" name="product_up_btn">Add Product</button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
         </div>
      </div>
   </Section>
<script>
    function getSubcategory(datavalue){
		$.ajax({
			url : "ajax.php",
			type : "POST",
			data : {datapost : datavalue },
			success: function(result){
				$("#subCategory").html(result);
			}



		});
	}
    const sliderimgshoe = ()=>{
        let sliderImgBtn = document.getElementById('sliderImgBtn');
    let sliderDIv = document.getElementById("sliderDIv");
    if(sliderImgBtn.checked  == true){
        sliderDIv.style.display="block";
    }else{
        sliderDIv.style.display="none";
    }

    }
   
</script>
  