<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
<?php  unset($_SESSION['msg']);  } ?>
<?php 
if(isset($_POST['delivery_charge_up_btn'])){
    $dcid = $_POST['dcid'];
    $page = $_POST['page'];
}elseif(isset($_SESSION['empty_something'])){
    $sess_array = $_SESSION['empty_something'];
    $dcid = $sess_array['dcid'];
    $page = $sess_array['page'];
}

$where = "dcid = ".$dcid;

$db_obj->select('delivery_charge',"*",null,$where,null,null);
$result = $db_obj->getResult();
$result = $result[0][0];
// print_r($result);
?>
<Section id="main">
      <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <div class="card py-5 px-5">
                    <h2 class="card-header  color-secondary font-size-20">Update Delivery Charge  </h2>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-containeer">
                                    <form action="./form_recurtion/delivery-charge-ac.php" method="POST">
                                        <div class="form-group">
                                            <label  class="font-size-18"> Point Name</label>
                                            <input type="text" value="<?php echo $result['point_name']; ?>" name="point_name" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18">Delivery Charge</label>
                                            <input type="number" value="<?php echo $result['charge_amount']; ?>" name="charge_amount" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <input value="<?php echo $dcid; ?>" name="dcid" hidden>
                                        <input value="<?php echo $page; ?>" name="page" hidden>
                                        <div class="form-group my-5">
                                          
                                            <input type="submit" name="delivery_charge_up_btn_sub" class="form-control font-size-18  btn btn-success" value="Add">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      </div>
   </Section>
