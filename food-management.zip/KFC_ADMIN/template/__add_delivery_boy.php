<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
<Section id="main">
      <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <div class="card py-5 px-5">
                    <h2 class="card-header  color-secondary font-size-20">Add Delivery Boy  </h2>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-containeer">
                                    <form action="./form_recurtion/delivery_boy_ac.php" method="POST">
                                        <div class="form-group">
                                            <label  class="font-size-18">Name</label>
                                            <input type="text" name="db_name"  class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18">phone</label>
                                            <input type="number" name="phone_no" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-2">
                                            <label  class="font-size-18">password</label>
                                            <input type="password" name="db_pass" class="form-control font-size-18  border-0 bg-light">
                                        </div>
                                        <div class="form-group my-5">
                                          
                                            <input type="submit" name="db_boy_add_btn" class="form-control font-size-18  btn btn-success" value="Add">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
      </div>
   </Section>

  
