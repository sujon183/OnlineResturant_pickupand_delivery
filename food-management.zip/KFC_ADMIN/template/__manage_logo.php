<?php
$db_obj->Select('site_info',"*",null,null,null,null);
$result = $db_obj->getResult();
$result = $result[0][0];

?>
<?php if(isset($_SESSION['msg'])){ ?>
    <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
  <?php  unset($_SESSION['msg']); } ?>
<div class="container">
    <div class="card p-5">
       <div class="card-body">
            <h1 class="mange_logo">Manage Logo</h1>
            <div class="form-container">
              <div class="row justify-content-between">
                <div class="col-12 col-md-5 g-2">
                    <h3 class="log-title">Top Logo</h3>
                    <form action="./form_recurtion/manage_site_info_ac.php" method="post" enctype="multipart/form-data" method="post" >
                    <div class="form-group my-3 font-size-18">
                        <label class="my-2">Top Logo</label>
                        <input type="file" name="top_logo" class="form-control font-size-18">
                       <div class="form-group my-3">
                       <button class="btn btn-success font-size-18 form-control" type="submit" name="btn_add_top_lg">Update</button>
                       </div>
                    </div>
                    </form>
                </div>
                <div class="col-12 col-md-5 g-2">
                    <h3 class="log-title">Footer Logo</h3>
                    <form action="./form_recurtion/manage_site_info_ac.php" method="post" enctype="multipart/form-data">
                    <div class="form-group my-3 font-size-18">
                        <label class="my-2">Footer logo</label>
                        <input type="file" name="footer_logo" class="form-control font-size-18">
                       <div class="form-group my-3">
                       <button class="btn btn-success font-size-18 form-control" type="submit" name="btn_add_bottom_lg">Update</button>
                       </div>
                    </div>
                    </form>
                </div> 
              </div>

              <div class="row  my-5 py-5 justify-content-center">
                <div class="col-6">
                    <h1 class="text-center color-primary font-size-20 log-title">Manage Home Page</h1>
                    <form action="./form_recurtion/manage_site_info_ac.php" method="post">
                       
                                <div class="form-group font-size-18 my-3">
                                    <label>Title</label>
                                    <input type="text" name="site_title" value="<?php echo$result['site_title']; ?>"  class="form-control font-size-18">
                                </div>
                                <div class="form-group font-size-18 my-3">
                                    <label>Phone Number</label>
                                    <input type="number" name="site_phone_number" value="<?php echo$result['site_phone_num']; ?>" class="form-control font-size-18">
                                </div>
                                <div class="form-group font-size-18 my-3">
                                    <label>Facebook Adress</label>
                                    <input type="text" name="fb_adress" value="<?php echo$result['fb_url']; ?>"  class="form-control font-size-18">
                                </div>
                                <div class="form-group font-size-18 my-3">
                                    <label>Whatsapp Number</label>
                                    <input type="number" name="whatsapp_num" value="<?php echo$result['whatsapp_number']; ?>" class="form-control font-size-18">
                                </div>
                         
                                <div class="form-group font-size-18 my-3">
                                    <label>Adress</label>
                                    <input type="text" name="c_address" value="<?php echo$result['company_address']; ?>" class="form-control font-size-18">
                                </div>
                                <input type="text" name="site_info_id" hidden value="<?php echo$result['site_id']; ?>">
                         <div class="form-group">
                            <button name="site_info_btn" class="form-control font-size-18 btn btn-success" type="submit">Update</button>
                         </div>
                           
                    </form>
                </div>
              </div>
            </div>
       </div>
    </div>
</div>

<style>
    .mange_logo{
        font-size: 3.5rem;
        color:#803C69;
        margin: 3rem 0;
    }
    .log-title{
        position: relative;
        font-size: 2.8rem;
        margin: 1.5rem 0;
        color:#803C69;
        text-align: center;
    }
    .log-title::after{
        content: "";
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 12rem;
        height: 0.2rem;
        background: #D90D94;
    }
</style>