<?php
  $join = "INNER JOIN menu ON product.menu_id = menu.menu_id 
  LEFT JOIN sub_menu ON product.sub_menu_id = sub_menu.sub_menu_id";

    $db_obj->selectInner('product','*',$join,null,null,2,2);
  $result = $db_obj->getjoinResult();
  $result = $result[0];
  $x = count($result);
   
  if(isset($_GET['page'])){
    $page = $_GET['page'];
 }else{
    $page=1;
 }

?>
        <?php 
        if(isset($_SESSION['msg'])){
        
        ?>

        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>

                <div class="mymodal py-5 w-100" id="promomodal">  
                                        <div class="row justify-content-center">
                                            <div class="col-12 col-md-4">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <div class="d-flex justify-content-between p-1 color-primary">
                                                            <h1>Product For Deals</h1> <h1 onclick="promo_closo_btn()"><span class="fa-solid fa-xmark"></span></h1>

                                                        </div>
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="form-container">
                                                            <form action="action/action.php" method="POST">
                                                           
                                                            <div class="form-group"  id="promoForm"> </div>
                                                            <input hidden value="<?php echo $page ?>" name="page">
                                                               
                                                                <div class="form-group fotn-size-20">
                                                                    <label class="font-size-20">Product Promote</label>
                                                                  <select name="dealInfo" class="form-control font-size-20">
                                                                       <option clas="font-size-18" value="">Select Option</option> 
                                                                       <option clas="font-size-18" value="0">Not Promote</option> 
                                                                       <option clas="font-size-18" value="1">Promote</option> 
                                                                  </select>
                                                                  <div class="form-group py-3">
                                                                    <button type="submit" name="promote_btn_update" class="btn btn-success font-size-20">Submit</button>
                                                                  </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

   <Section id="main">
      
        <section id="offerProducts" class="py-3 mx-3">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center background-color px-3">
                        <div class="post_info "><span class="fa-solid fa-table font-size-18 px-2"></span><h3>All Post Information</h3></div>
                        <div class="add_offer">
                             <a href="add-product.php" class="btn btn-primary report_btn font-size-12">Add Product</a>
                             <a href="option-product.php" class="btn btn-info report_btn font-size-12">Product Option</a>
                             <a href="#" class="btn btn-success report_btn font-size-12">Product Sales</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center  px-3 py-2 color-white-bg">
                       
                        <div class="form-container">
                            <h3>
                                <form action="#">
                                    <span class="px-2">Show</span><select name="" id="">
                                        <option value="10">10</option>
                                        <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                    <span class="px-2">Entries</span>
                                </form>
                            </h3>
                        </div>
                        <div class="form-container">
                            <h3>
                                <form action="#" class="border d-flex align-items-center">
                                  <input type="text" class="border-0 search_input font-size-16 px-2">
                                  <button class="btn"><span class="fa-solid fa-search font-size-16"></span></button>
                                </form>
                            </h3>
                        </div>
                    
                    </div>
                      <table class="table table-striped table-hover my-3 text-center">
                    <thead class="color-white-50-bg font-size-16 font-playfair">
                        <tr>
                           <th>No.</th>
                           <th>Name</th>
                           <th>Is Banner</th>
                           <th>Category Name</th>
                           <th> Sub Category Name</th>
                           <th> Current Price</th>
                           <th> Offer Price</th>
                           <th> Deal Status</th>
                           <th>Image</th>
                           <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-16">
                        <?php for($i=0; $i<$x; $i++){ ?>
                  
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $result[$i]['pro_name']; ?></td>
                            <td><?php 
                                $slider_img = $result[$i]['slider_img'];
                                if($slider_img != null){
                                    ?>
                                    <sdpan class="bg-success p-1 text-white">For Banner</sdpan>
                                    <?php  }else{ ?>
                                        <sdpan class="bg-danger p-1 text-white">Not Promotode</sdpan>
                                <?php }  ?>
                            </td>

                            <td> <?php  echo $result[$i]['menu_name']; ?></td>
                            <td> 
                                <?php $sub_category = $result[$i]['sub_menu_name'];
                                if($sub_category != null){ echo $sub_category; ?>
                                
                                <?php }else{ ?>
                                    <sdpan class="bg-danger p-1 text-white">Only Category</sdpan>
                               <?php } ?>
                               
                            </td>
                            <td> <?php echo $result[$i]['pro_regular_price']; ?><span class=" px-1 fa-solid fa-euro"></span></td>
                            <td> <?php echo $result[$i]['pro_offer_price']; ?><span class=" px-1 fa-solid fa-euro"></span></td>
                            <td> 
                                <?php $deal = $result[$i]['deal_satus'];
                                if($deal == 0){ ?>  <sdpan class="bg-danger p-1 text-white">Not Promotode</sdpan>
                                <?php }else{ ?>
                                    <sdpan class="bg-success p-1 text-white">Promotode</sdpan>
                               <?php } ?>
                            </td>
                            <td><img src="assets/images/<?php echo $result[$i]['pro_img']; ?>" class="product_images"></td>
                            <td>
                                <div class="d-flex justify-content-center">

                           
                                    <form action="action/action.php" class="px-1" method="POST">
                                        <?php
                                        $active = $result[$i]['pro_active']; 
                                       
                                         ?>
                                        <input type="text" value="<?php echo $result[$i]['pid']; ?>" hidden name="pro_id">
                                        <input type="text" value="<?php echo $active; ?>" hidden name="pro_active">
                                        <input type="text" value="<?php echo $page; ?>" hidden name="page">
                                        <?php 
                                         if($active == 0){ ?> 
                                           <button type="submit" class="font-size-16 btn btn-danger" name="product_active_btn">Deactive</button>
                                            <?php }else{ ?>
                                                <button type="submit" class="font-size-16 btn btn-success" name="product_active_btn">Active</button>
                                           <?php } ?>
                                       
                                    </form>
                                    <form action="update-product.php" class="px-1" method="POST">
                                    <input type="text" value="<?php echo $result[$i]['pid']; ?>" hidden name="pro_id">
                                    <input type="text" value="<?php echo $page; ?>" hidden name="page">
                                        <button type="submit" class="font-size-16 btn btn-warning" name="update_product_btn">Update</button>
                                    </form>
                                    <form action="action/action.php" class="px-1" method="post">
                                    <input type="text" value="<?php echo $result[$i]['pid']; ?>" hidden name="pro_id">
                                        <button type="submit" class="font-size-16 btn btn-danger" name="product_delete_btn">Delete</button>
                                    </form>
                                    
                                        <input name="pid" hidden value="<?php echo $result[$i]['pid']; ?>">
                                    <button value="<?php echo $result[$i]['pid']; ?>" onclick="promoted_open(this.value)" name="promo_up_btn" class=" btn font-size-20" ><span class="fa fa-outdent"></span></button>
                                   
                                    
                               </div>
                            </td>
                       </tr>
                       <?php } ?>
                    </tbody>
                 </table>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="font-size-16">Showing 1 to 4 items of 4 Entries</p>
                        <nav aria-label="Page navigation example" class="mypagination">
                          <?php echo  $db_obj->paginationJoin('product',$join,null,2,2); ?>
                          </nav>
                    </div>
                </div>
            </div>
        </section>
   </Section>

   <script>
    // promo update 
     
    var promomodal = document.getElementById("promomodal");
    var promoForm = document.getElementById("promoForm");
    let y = document.createElement("input");
     
    const promoted_open=(data)=>{
        promomodal.style.top='2rem';
        var x = data;
       
        y.setAttribute('value',x);
        y.setAttribute('name','pid');
        y.setAttribute('type','hidden');
        promoForm.appendChild(y);

       
    }
  const promo_closo_btn = ()=>{
    promomodal.style.top='-100rem';
    revome.y;
  }
   </script>