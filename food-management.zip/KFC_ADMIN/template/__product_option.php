

<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
        <!-- total order with select time  -->
        <div id="mymodal" class="mymodal py-5 w-100">
          <div class="row justify-content-center">
            <div class="col-12 col-md-5">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between">
                             <h1 class="color-primary">Add Option Product </h1>
                             <h1 class="color-primary" id="Add_product_close_btn"><span class="fa-solid fa-xmark"></span></h1>
                        </div>
                       
                        
                    </div>
                    
                    <div class="card-body">
                        <div class="form-container">
                            <form action=" <?php $_SERVER['PHP_SELF'];  ?>" method="POST">
                                <div class="form-group my-4 font-size-18">
                                    <label>Product Option Title</label>
                                    <input type="text" class="form-control font-size-20" class="title" name="op_name">
                                </div>
                                <div class="form-group my-4 font-size-20">
                                    <label>Product Option Type</label>
                                    <select name="type" id="" class="form-control font-size-20">
                                        <option value="single_selection">SingleSelection </option>
                                        <option value="multiple_selection">Multiple Selection </option>
                                        <option value="2_selection">2 Selection </option>
                                        <option value="paid_multiple_selection">Paid Multiple Selection </option>
                                    </select>
                                </div>
                                <div class="form-group my-5 font-size-18">
                                   
                                    <input name="op_add_btn" type="submit" class="form-control btn color-primary-bg text-white report_btn font-size-20" value="Add">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> 
               
          </div>
        </div>
        <?php    
        $db_obj->select("op_product","*",null,null,null,'2');
       $result = $db_obj->getResult();
       $result = $result[0];
       $x = count($result);
       
       
        
        
        
        ?>
    <div class="container">
         <div class="row justify-content-center my-5">
        <div class="col-12">
           <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3><span class="fa-solid fa-table"></span> All Post Information</h3>
                        <h4 class="font-playfair  text-capitalize color-primary  report-table-title "> 
                            <a href="#" id="Add_product_open_btn" >Add</a>
                        </h4>
                    </div>
                </div>
           </div>
                
                <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>No.</th>
                            <th>Name</th>
                            <th>Option Type</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                     <?php
                     for($i=0; $i<$x; $i++){  ?>
                      
                        <tr>
                            <td><?php echo $i+1;  ?></td>
                            <td><?php echo $result[$i]['op_name'];  ?></td>
                            <td> <?php echo $result[$i]['op_type'];  ?></td>
                            <td>
                                <div class="d-flex justify-content-center">

                                        <?php
                                        if(isset($_GET['page'])){
                                            $page = $_GET['page'];
                                        }else{
                                            $page = 1;
                                        }
                                        
                                        ?>
                            
                                    <form action="update_option_product.php" class="px-1" method="POST">
                                        <input type="text" value="<?php  echo $result[$i]['op_id'];  ?>" hidden name="option_id">
                                        <input type="text" value="<?php  echo $result[$i]['op_type'];  ?>" hidden name="op_type">
                                        <input type="text" value="<?php  echo $page;  ?>" hidden name="page">
                                        <input type="text" value="<?php  echo $result[$i]['op_name'];  ?>" hidden name="op_name">
                                        <button type="submit" class="font-size-16 btn btn-dark" name="up_op_name">Edit</button>
                                    </form>
                                    <form action="update_option_product.php" class="px-1" method="POST">
                                        <input type="text" value="<?php  echo $result[$i]['op_id'];  ?>" hidden name="option_id">
                                        <button type="submit" class="font-size-16 btn btn-danger" name="op_pro_dlt" >Delete</button>
                                    </form>
                               </div>
                          </td>
                        </tr>
                        <?php } ?>
                       
                    </tbody>
                 </table>
               
                 <nav aria-label="Page navigation example" class="mypagination">
                   <?php echo $db_obj->pagination("op_product",null,null,'2'); ?>
                  </nav>
            
        </div>
     </div>
 
    </div>
   
  </section>