<?php if(isset($_SESSION['msg'])){ ?>
    <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
  <?php  unset($_SESSION['msg']); } ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 col-12">
            <div class="card py-2 my-5">
            <h1 class="card-header">Admin Login</h1>
                <div class="card-body">
                    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                        <div class="form-group font-size-18">
                            <label for="userName">User Name</label>
                            <input type="text" name="usName" class="form-control font-size-18">
                        </div>
                        <div class="form-group font-size-18">
                            <label for="Password">Password</label>
                            <input type="password" name="pass" class="form-control font-size-18">
                        </div>
                        <div class="form-group my-3">
                            <button name="admin_login_btn" class="btn color-secondary-bg form-control font-size-18 text-white report_btn">Login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
   
</div>