<div class="container">
    <div class="card my-2">
        <h2 class="card-header"><span class="fa-solid fa-file"></span> General Information</h2>
    </div>
    <div class="card-body">
        <div class="form_container">
            <form action="#" method="post" enctype="multipart/form-data">
                <div class="border p-3">
                    <div class="form-group font-size-18 py-1">
                        <label>Set Notify Email</label>
                        <input type="email" placeholder="xyz@gmail.com" class="form-control font-size-18">
                    </div>
                    <div class="row justify-content-between align-items-center">
                        <div class="col-6">
                        <div class="form-group font-size-18">
                            <label>Website Promo Alert Image</label>
                            <input type="file" class="form-control font-size-18">
                        </div>
                        </div>
                        <div class="col-6">
                        <div class="form-group font-size-18">
                            <label>Special Offer Image</label>
                            <input type="file" class="form-control font-size-18">
                        </div>
                        </div>
                       
                    </div>
                    <div class="form-group my-2 font-size-18">
                        <label>Discount</label>
                        <input type="number" placeholder="10" class="form-control font-size-18">
                    </div>
                </div>
                <div class="border p-3">
                    <div class="form-check form-switch font-size-18">
                    <label class="form-check-label">Especes</label>
                    <input class="form-check-input font-size-18" type="checkbox" id="flexSwitchCheckDefault">
                    </div>
                    <div class="form-check form-switch font-size-18">
                    <label class="form-check-label">Especes</label>
                    <input class="form-check-input font-size-18" type="checkbox" id="flexSwitchCheckDefault">
                    </div>
                    <div class="form-check form-switch font-size-18">
                    <label class="">Especes</label>
                    <input class="form-check-input font-size-18" type="checkbox" id="flexSwitchCheckDefault">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>