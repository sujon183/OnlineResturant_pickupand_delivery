<?php

$db_obj->select('delivery_boy',"*",null,null,null,4,1);
$result = $db_obj->getResult();
$result = $result[0];
// print_r($result);
$x = count($result);
if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page =1;
}


?>



<div class="container">
         <div class="row justify-content-center my-5">
        <div class="col-12">
           
                <h1 class="font-playfair  text-capitalize color-primary mb-5 report-table-title "> 
                    <a href="add_delivery_boy.php">Add Delivery Boy</a>
                </h1>
                <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>DBID</th>
                            <th>Name</th>
                            <th>Phone Number</th>
                            <th>Password</th>
                            <th>Added On</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                        <?php
                        for($i=0; $i<$x; $i++){ ?>
                        <tr>
                            <td><?php echo $result[$i]['dbid']; ?></td>
                            <td><?php echo $result[$i]['deliver_boy_name']; ?></td>
                            <td><?php echo $result[$i]['db_phone_number']; ?></td>
                            <td><?php echo $result[$i]['db_pass']; ?></td>
                            <td><?php echo $result[$i]['date']; ?></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="./form_recurtion/delivery_boy_ac.php" class="px-1" method="POST">
                                        <input name="dbid" value="<?php echo $result[$i]['dbid']; ?>" hidden>
                                        <input name="page" value="<?php echo $page; ?>" hidden>
                                        <?php 
                                        $active = $result[$i]['db_active'];  ?>
                                        <input name="active" value="<?php echo $active; ?>" hidden>
                                        <?php
                                        if($active == 0){
                                        ?>
                                        <button type="submit" name="db_active_btn" class="font-size-16 btn btn-danger">Deactive</button>
                                        <?php }else{ ?>
                                         <button type="submit" name="db_active_btn" class="font-size-16 btn btn-success">Active</button>
                                         <?php } ?>
                                    </form>
                                    <form action="update-delivery-boy.php" method="POST" class="px-1">
                                    <input name="dbid" value="<?php echo $result[$i]['dbid']; ?>" hidden>
                                      <input name="page" value="<?php echo $page; ?>" hidden>
                                        <button type="submit" name="db_boy_up" class="font-size-16 btn btn-warning">Update</button>
                                    </form>
                                    <form action="./form_recurtion/delivery_boy_ac.php" class="px-1" method="POST">
                                     <input name="dbid" value="<?php echo $result[$i]['dbid']; ?>" hidden>
                                        <button type="submit" name="db_boy_dlt_btn" class="font-size-16 btn btn-danger">Delete</button>
                                    </form>
                               </div>
                          </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                 </table>
                 <nav aria-label="Page navigation example" class="mypagination">
                   <?php echo $db_obj->pagination("delivery_boy",null,null,4,1); ?>
                  </nav>
            
        </div>
     </div>
 
    </div>