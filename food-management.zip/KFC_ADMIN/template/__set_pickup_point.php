<?php

$db_obj->select('pickupPoint',"*",null,null,null,4,1);
$result = $db_obj->getResult();
$result = $result[0];
// print_r($result);
$x = count($result);
if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page =1;
}


?>



<div class="container">
         <div class="row justify-content-center my-5">
        <div class="col-12">
           
                <h1 class="font-playfair  text-capitalize color-primary mb-5 report-table-title "> 
                    <a href="add_set_pickup_point.php">Add Pickup Point</a>
                </h1>
                <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>PICk ID</th>
                            <th>Point Name</th>
                            <th>Postal Code</th>
                            <th>Opening Time</th>
                            <th>Closing Time</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                        <?php
                        for($i=0; $i<$x; $i++){ ?>
                        <tr>
                            <td><?php echo $result[$i]['pic_id']; ?></td>
                            <td><?php echo $result[$i]['pickup_point']; ?></td>
                            <td><?php echo $result[$i]['postal_code']; ?></td>
                            <td><?php echo $result[$i]['opening']; ?></td>
                            <td><?php echo $result[$i]['closing']; ?></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="./form_recurtion/delivery_boy_ac.php" class="px-1" method="POST">
                                        <input name="pic_id" value="<?php echo $result[$i]['pic_id']; ?>" hidden>
                                        <input name="page" value="<?php echo $page; ?>" hidden>
                                        <?php 
                                        $active = $result[$i]['active'];  ?>
                                        <input name="active" value="<?php echo $active; ?>" hidden>
                                        <?php
                                        if($active == 0){
                                        ?>
                                        <button type="submit" name="active_btn" class="font-size-16 btn btn-danger">Deactive</button>
                                        <?php }else{ ?>
                                         <button type="submit" name="active_btn" class="font-size-16 btn btn-success">Active</button>
                                         <?php } ?>
                                    </form>
                                    <form action="update-delivery-boy.php" method="POST" class="px-1">
                                    <input name="pic_id" value="<?php echo $result[$i]['pic_id']; ?>" hidden>
                                      <input name="page" value="<?php echo $page; ?>" hidden>
                                        <button type="submit" name="db_boy_up" class="font-size-16 btn btn-warning">Update</button>
                                    </form>
                                    <form action="./form_recurtion/delivery_boy_ac.php" class="px-1" method="POST">
                                     <input name="pic_id" value="<?php echo $result[$i]['pic_id']; ?>" hidden>
                                        <button type="submit" name="db_boy_dlt_btn" class="font-size-16 btn btn-danger">Delete</button>
                                    </form>
                               </div>
                          </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                 </table>
                 <nav aria-label="Page navigation example" class="mypagination">
                   <?php echo $db_obj->pagination("delivery_boy",null,null,4,1); ?>
                  </nav>
            
        </div>
     </div>
 
    </div>