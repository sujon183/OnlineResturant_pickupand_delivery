

<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
<section id="main" class="py-3">
    <h1 class="font-playfair font-size-20 text-center text-uppercase">
        <span class="color-primary-bg py-2 px-3 text-white">Dashboard</span>
    </h1>
            <!-- select time to see how manay orders completed with selected time  -->
    <div class="row justify-content-center my-5" >
        <div class="col-md-8 col-12">
            <div class="card color-primary-bg p-3">
                <h2 class="card-title font-playfair text-white">Get Sales Reports</h2>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group">
                            <h3 class="text-white">From</h3>
                            <input type="date" class="form-control font-size-16">
                        </div>
                        <div class="form-group">
                            <h3 class="text-white mt-3">To</h3>
                            <input type="date" class="form-control font-size-16">
                        </div>
                        <div class="form-group mt-3">
                            <button type="submit"  class=" color-btn-bg font-size-20 w-100 report_btn btn" >Submit</button>
                        </div>
                    </div>
                   
                </div>
              
            </div>
            <hr class="py-1 mt-5">
        </div>
       
     </div>
        <!-- total order with select time  -->
     <div class="row justify-content-center">
        <div class="col-md-8 col-12">
           
                <h1 class="font-playfair text-center text-capitalize color-primary mb-5 report-table-title text-shadow"> 
                    Reports (Total Order:0) / (Total Amount : €)
                </h1>
                <table class="table table-striped table-hover text-center">
                    <thead class="color-primary-bg text-white text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>order id</th>
                            <th>pay.method</th>
                            <th>total</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                        <tr>
                            <td class="text-white"><span class="color-primary-bg px-2 py-1 mx-1">23</span><span class="color-primary-bg px-2 py-1 mx-1">24</span></td>
                            <td>Cash</td>
                            <td>1200 <span class="fa-solid fa-euro"></span></td>
                        </tr>
                    </tbody>
                 </table>
            
        </div>
     </div>
     <!-- // set pickup time and resturant open time  -->
     <div class="row justify-content-center py-5">
        <div class="col-md-4">
            <div class="card p-3">
                <h1 class="resturant_open color-primary text-shadow card-title text-center">Set resturant Open & Close Time</h1>
                <div class="card-body">
                    <div class="form-container m-auto">
                        <div class="form-group d-flex align-items-center  font-size-18 justify-content-around">
                            <div class="px-2 d-flex align-items-center"><span class="fa-solid fa-clock pr-1"></span><span>Open Time</span></div><input type="time" class="form-control w-50">
                        </div>
                        <div class="form-group d-flex align-items-center  font-size-18 justify-content-around mt-2">
                            <div class="px-2 d-flex align-items-center"><span class="fa-solid fa-clock pr-1"></span><span>Close Time</span></div><input type="time" class="form-control w-50">
                        </div>
                        <div class="form-group mt-3 ">
                            <center><button  class="btn color-btn-bg font-size-18 w-100 report_btn">Submit</button></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card p-3">
                <h1 class="resturant_open color-primary text-shadow card-title text-center">Set Order Pickupp  Time</h1>
                <div class="card-body">
                    <div class="form-container m-auto">
                        <div class="form-group d-flex align-items-center  font-size-18 justify-content-around">
                            <div class="px-2 d-flex align-items-center"><span class="fa-solid fa-clock pr-1"></span><span>Pickup Time</span></div><input type="time" class="form-control w-50">
                        </div>
                        
                        <div class="form-group mt-3 ">
                            <center><button  class="btn color-btn-bg font-size-18 w-100 report_btn">Submit</button></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
     </div>

     <!-- pickup and delivaery order and pickup time list  -->
     <div class="row justify-content-center py-3">
        <!-- pickup & order time  -->
        <div class="col-4">
            <h1 class="mb-3">Pickup & deliver order</h1>
            <form action="" class="form-check form-switch">
                <input type="checkbox" class="form-check-input font-size-20"> <span class="font-size-20">Deliver Order</span>
            </form>
            <form action="" class="form-check form-switch">
                <input type="checkbox" class="form-check-input font-size-20 "> <span class="font-size-20">Pickup Order</span>
            </form>
        </div>
        <!-- pickup time List   -->
        <div class="col-4">
            <h1 class="mb-3"><span class="fa-solid fa-clock"></span>Pickup time list</h1>
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">psl_id</th>
                    <th scope="col">Pickup Time</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>02:32:00</td>
                    <td><button class="btn btn-success">Action</button><button class="btn btn-danger mx-2">Delete</button></td>
                
                  </tr>
                  <tr>
                    <th scope="row">1</th>
                    <td>02:32:00</td>
                    <td><button class="btn btn-success">Action</button><button class="btn btn-danger mx-2">Delete</button></td>
                
                  </tr>
                  <tr>
                    <th scope="row">1</th>
                    <td>02:32:00</td>
                    <td><button class="btn btn-success">Action</button><button class="btn btn-danger mx-2">Delete</button></td>
                
                  </tr>
                </tbody>
              </table>
        </div>
     </div>
  </section>