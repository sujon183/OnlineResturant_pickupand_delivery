<?php
$join =  "menu  
ON sub_menu.menu_id = menu.menu_id";  
$db_obj->select('sub_menu','*',$join,null,null,"2");
$result = $db_obj->getResult();
$result = $result[0];
$x = count($result);

?>

<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
        <!-- total order with select time  -->
    <div class="container">
         <div class="row justify-content-center my-5">
        <div class="col-12">
           
                <h1 class="font-playfair  text-capitalize color-primary mb-5 report-table-title "> 
                    <a href="add-sub-menu.php">Add Menu</a>
                </h1>
                <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>Si. No.</th>
                            <th>MENU</th>
                            <th>SUB MENU</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                      <?php   
                      for($i=0; $i<$x; $i++){


                
                      
                      
                      ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $result[$i]['menu_name'];  ?></td>
                            <td><?php echo $result[$i]['sub_menu_name'];  ?></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="update-sub-menu.php" method="POST" class="px-1">
                                    <?php if(isset($_GET['page'])){
                                        $page = $_GET['page'];
                                     }else{
                                      $page = 1;
                                     } 
                                     ?>
                                        <input type="text" value="<?php echo $page; ?>" hidden name="page">
                                        <input type="text" value="<?php echo $result[$i]['sub_menu_id'];  ?>" hidden name="sub_menu_id">
                                        <button type="submit" class="font-size-16 btn btn-warning" name="up_sub_menu_btn">Update</button>
                                    </form>
                                    <form action="" class="px-1">
                                        <input type="text" value="1" hidden>
                                        <button type="submit" class="font-size-16 btn btn-danger">Delete</button>
                                    </form>
                               </div>
                          </td>
                        </tr>
                     <?php       } ?>
                    </tbody>
                 </table>
                 <nav aria-label="Page navigation example" class="mypagination">
                    <?php
                    
                   echo  $db_obj->pagination('sub_menu',$join,null,"2");
                    
                    
                    ?>
                  </nav>
            
        </div>
     </div>
 
    </div>
  </section>