

<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
<?php  unset($_SESSION['msg']);  } ?>

<?php
$db_obj->select('delivery_charge',"*",null, null, null,4,1);
$pagination = $db_obj->pagination('delivery_charge',null, null,4,1);
$result = $db_obj->getResult();
$result = $result[0];
$x = count($result);

if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page =1;
}



?> 
        <!-- total order with select time  -->
    <div class="container">
         <div class="row justify-content-center my-5">
        <div class="col-12">
           
                <h1 class="font-playfair  text-capitalize color-primary mb-5 report-table-title "> 
                    <a href="add-delivery-charge.php">Set Delivery Charge</a>
                </h1>
                <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>SL.</th>
                            <th>Point Name</th>
                            <th>Charge</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                        <?php
                        
                        for($i=0; $i<$x; $i++){ ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $result[$i]['point_name']; ?></td>
                            <td><?php echo $result[$i]['charge_amount']; ?> <span class="fa-solid fa-euro"></span></td>
                           
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="./form_recurtion/delivery-charge-ac.php" class="px-1" method="post">
                                        <input name="dcid" value="<?php echo $result[$i]['dcid']; ?>" hidden>
                                        <input name="delivery_active" value="<?php echo $result[$i]['delivery_active']; ?>" hidden>
                                        <input name="page" value="<?php echo $page; ?>" hidden>
                                        <?php 
                                        $active = $result[$i]['delivery_active'];
                                        if($active ==1){ ?>
                                        <button type="submit" name="db_charge_ac_btn" class="font-size-16 btn btn-success">Active</button>
                                        <?php } else{ ?>
                                            <button type="submit" name="db_charge_ac_btn" class="font-size-16 btn btn-danger">Deactive</button>
                                            <?php } ?>
                                    </form>
                                    <form action="update-delivery-charge.php" method="post" class="px-1">
                                    <input name="dcid" value="<?php echo $result[$i]['dcid']; ?>" hidden>
                                     <input name="page" value="<?php echo $page; ?>" hidden>
                                        <button name="delivery_charge_up_btn" type="submit" class="font-size-16 btn btn-warning">Update</button>
                                    </form>
                                    <form action="./form_recurtion/delivery-charge-ac.php" class="px-1" method="post">
                                    <input name="dcid" value="<?php echo $result[$i]['dcid']; ?>" hidden>
                                        <button name="deliver_charge_dlt_btn" type="submit" class="font-size-16 btn btn-danger">Delete</button>
                                    </form>
                               </div>
                          </td>
                        </tr>
                      <?php } ?>
                       
                    </tbody>
                 </table>
                 <nav aria-label="Page navigation example" class="mypagination">
                    <?php  echo $pagination;  ?>
                  </nav>
            
        </div>
     </div>
 
    </div>
  </section>
