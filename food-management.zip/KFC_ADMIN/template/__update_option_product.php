<?php
              
          

if(isset($_POST['up_op_name'])){
    $op_id = $_POST['option_id'];
    $op_name = $_POST['op_name'];
     $op_type = $_POST['op_type'];
    $page = $_POST['page'];
        
    }elseif(isset($_SESSION['added_product_info'])){
            $array_send = $_SESSION['added_product_info'];
            $op_id = $array_send['op_id'];
            $op_type = $array_send['op_type'];
            $op_name = $array_send['op_name'];
          }else{
            header('location: option-product.php');
          }

    


    if($op_type == 'paid_multiple_selection'){
        $id = "paidable_btn";
    }else{
        $id = "un_paidable_btn";
    }
   
    $where = 'op_id ='.$op_id;

    $db_obj->select("add_op_product","*",null, $where,null,null);
    $result = $db_obj->getResult();
    $result = $result[0];
   
     $x = count($result);
 
   
    ?>
    
    <?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
             <!-- unpaid modal  -->
        <div id="unpaid_multiple_modal" class="mymodal py-5 w-100">
          <div class="row justify-content-center">
            <div class="col-12 col-md-5">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between">
                             <h1 class="color-primary">Add paid product </h1>
                             <h1 class="color-primary" id="unpaid_multiple_modal_close_btn"><span class="fa-solid fa-xmark"></span></h1>
                        </div>
                       
                        
                    </div>
                    
                    <div class="card-body">
                        <div class="form-container">
                            <form action="./form_recurtion\form_action.php" method="POST" enctype="multipart/form-data">
                                <div class="form-group my-4 font-size-18">
                                    <label>Name</label>
                                    <input type="text" class="form-control font-size-20" name="name">
                                </div>
                                <input type="text" value="<?php echo $op_type; ?>" name="op_type" hidden>
                                <div class="form-group my-4 font-size-20">
                                    <label>Product Description</label>
                                    <input type="text" class="form-control font-size-20" name="description">
                                </div>
                               
                                <div class="form-group my-4 font-size-20">
                                    <label>Product Image</label>
                                    <input type="file" class="form-control font-size-20" name="img">
                                </div>
                                <input type="text" value="<?php echo $op_id; ?>" name="op_id" hidden>
                                <input type="text" value="<?php echo $op_name; ?>" name="op_name" hidden>
                                <div class="form-group my-5 font-size-18">
                                   
                                    <input type="submit" name="add_option_product_btn_unpaid" class="form-control btn color-primary-bg text-white report_btn font-size-20" value="Add">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> 
               
          </div>
        </div>

        <!-- // unpaid MODAL END -->

        <!-- paid modal  -->
        <div id="paid_multiple_modal" class="mymodal py-5 w-100">
          <div class="row justify-content-center">
            <div class="col-12 col-md-5">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between">
                             <h1 class="color-primary">Add paid product </h1>
                             <h1 class="color-primary" id="add_product_close_btn"><span class="fa-solid fa-xmark"></span></h1>
                        </div>
                       
                        
                    </div>
                    
                    <div class="card-body">
                        <div class="form-container">
                            <form action="./form_recurtion\form_action.php" method="POST" enctype="multipart/form-data">
                                <div class="form-group my-4 font-size-18">
                                    <label>Name</label>
                                    <input type="text" class="form-control font-size-20" name="name">
                                </div>
                                <div class="form-group my-4 font-size-20">
                                    <label>Product Description</label>
                                    <input type="text" class="form-control font-size-20" name="description">
                                </div>
                                <div class="form-group my-4 font-size-20">
                                    <label>Product Price</label>
                                    <input type="number" class="form-control font-size-20" name="price">
                                </div>
                                <div class="form-group my-4 font-size-20">
                                    <label>Product Image</label>
                                    <input type="file" class="form-control font-size-20" name="img">
                                </div>
                                 <input type="text" value="<?php echo $op_id; ?>" name="op_id" hidden>
                                <input type="text" value="<?php echo $op_name; ?>" name="op_name" hidden>
                                <input type="text" value="<?php echo $op_type; ?>" name="op_type" hidden>
                                <div class="form-group my-5 font-size-18">
                                   
                                    <input type="submit" name="add_option_product_btn_paid" class="form-control btn color-primary-bg text-white report_btn font-size-20" value="Add">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> 
               
          </div>
        </div>
        <!-- // paid MODAL END -->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="card px-2 pb-5">
                    <h2 class="card-header  color-primary py-2">Product Option Edit</h2>
                    <div class="card-body">
                        <div class="form-container">
                            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
                                <div class="fomr-group font-size-18">
                                    <label>Product Option Title</label>
                                    <input type="text" value="<?php echo $op_name; ?>" placeholder="<?php echo $op_name;  ?>" class="form-control font-size-18" name="op_name">
                                </div>
                                <input type="text" value="<?php echo $op_id; ?>" hidden name="op_id">
                                <input type="text" value="<?php echo $page; ?>" hidden name="page">
                                <div class="fomr-group font-size-18 my-3">
                                    <button type="submit" name="op_pro_up" class="btn btn-success font-size-18">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between">
                            <div class="d-flex align-items-center"><span class="fa-solid fa-table font-size-16"></span><span class="px-2 font-size-18 mt-1">All Post Information</span></div>
                            <div>
                              <button class="btn btn-primary font-size-18" id="<?php echo $id; ?>" >Add</button>
                             </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <select name="" id="" class="font-size-18 px-5 py-1">
                                    <option value="10">10</option>
                                    <option value="25">25</option>
                                    <option value="50">50</option>
                                    <option value="100">100</option>
                                </select>
                            </div>
                            <form action="#" class="d-flex align-item-center border px-2"><input type="text" class="search_input font-size-18 px-2 border-0"> <button class="border-0 bg-white"> <span class="fa-solid fa-search"></span></button></form>
                        </div>
                        </div>
                        <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>No.</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th> image</th>
                            <th>price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                    
                    <?php  for($i=0; $i<$x; $i++){ ?>
                      
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $result[$i]['name']; ?></td>
                            <td> <?php echo $result[$i]['description']; ?></td>
                            <td><img src="assets/images/<?php echo $result[$i]['op_pr_img']; ?>" alt="" class="product_images"></td>
                            <td> <?php echo $result[$i]['price'];  ?> <span class="fa-solid fa-euro"></span></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="./form_recurtion\form_action.php" method="POST">
                                        <input type="text" value="<?php echo $op_id; ?>" name="op_id" hidden>
                                        <input type="text" value="<?php echo $op_name; ?>" name="op_name" hidden>
                                        <input type="text" value="<?php echo $op_type; ?>" name="op_type" hidden>
                                        <input type="text" value="<?php echo $result[$i]['add_op_id']; ?>" hidden name="add_op_id">
                                        <button type="submit" name="product_option_dlt_btn" class="btn btn-danger font-size-18">Delete</button>
                                    </form>                                    
                               </div>
                          </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                 </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- // table  -->

  
     
   
