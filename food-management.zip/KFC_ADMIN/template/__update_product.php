<?php 
if(isset($_POST['update_product_btn'])){
    $pid = $_POST['pro_id'];
    $where = 'pid='.$pid;
    $page = $_POST['page'];
    $join = "INNER JOIN menu ON product.menu_id = menu.menu_id 
             LEFT JOIN sub_menu ON product.sub_menu_id = sub_menu.sub_menu_id";
    $db_obj->selectInner('product','*',$join,$where, null, null);
    $op_result = $db_obj->getjoinResult();

    $op_result = $op_result[0][0];
    $product_name = $op_result['pro_name'];
    $pro_desc = $op_result['pro_desc'];
    $pro_regular_price = $op_result['pro_regular_price'];
    $pro_offer_price = $op_result['pro_offer_price'];
    $menu_name = $op_result['menu_name'];
    $menu_id = $op_result['menu_id'];
    $sub_category = $op_result['sub_menu_name'];
    $sub_category_id = $op_result['sub_menu_id'];
    $checked = "checked";
    $special_price = $op_result['special_price'];
    $slider_img = $op_result['slider_img'];
    $discount = $op_result['discount'];
    $option_pro_id = $op_result['option_pro_id'];
    $op_id_array = explode(',',$option_pro_id);

}
$db_obj->select('op_product',"*",null,null,null,null);
$result = $db_obj->getResult();
$result = $result[0];
$x = count($result);
$sql = "SELECT * FROM menu";
$db_obj->sql($sql);
$sqlResult = $db_obj->getsqlResult();
$sqlResult = $sqlResult[0];
$y = count($sqlResult);

if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page =1;
}

?>
 <?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
<Section id="main">
      <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <h1 class="card-header  color-secondary font-size-20">Add Product  </h1>
                    <div class="card-body">
                        <form action="./form_recurtion/product_update_act.php" class="font-size-20" method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-8 col-12">
                                <div class="form-container">
                                    
                                        <div class="form-group my-2">
                                            <label>Product Name</label>
                                            <input type="text" value="<?php echo $product_name; ?>" class="form-control font-size-18" required name="Product_Name">
                                        </div>
                                        <div class="form-group my-2">
                                            <label>Product Description</label>
                                            <!-- textarea don't give up a line break for remove first space  -->
                                        <textarea name="pr_desc"  id="" cols="30" rows="10" class="form-control font-size-18 resize-none"> <?php echo $pro_desc; ?> </textarea>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Regular Price</label>
                                                    <input type="number" value="<?php echo $pro_regular_price; ?>" name="r_price" class="form-control font-size-18" placeholder="200">
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Offer Price</label>
                                                    <input type="number" value="<?php echo $pro_offer_price; ?>" name="o_price" class="form-control font-size-18" placeholder="200">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Category</label>
                                                    <select name="category" onchange="getSubcategory(this.value )"  class="form-control font-size-18">
                                                        <option value="<?php echo $menu_id;  ?>" ><?php echo $menu_name; ?></option>
                                                       <?php
                                                       for($i=0; $i<$y; $i++){ ?>
                                                       <option value="<?php echo $sqlResult[$i]['menu_id']; ?>"><?php echo $sqlResult[$i]['menu_name']; ?></option>
                                                    <?php }  ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <div class="form-group my-2">
                                                    <label>Sub Category</label>
                                                    <select name="subCategory" id="subCategory" class="form-control font-size-18">
                                                        <option value="<?php echo $sub_category_id; ?>" ><?php echo $sub_category; ?></option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group my-2">
                                            <label>Product Image</label>
                                            <input type="file" name="pr_img" class="form-control font-size-18">
                                        </div>
                                    
                                </div>
                            </div>
                            <div class="col-md-4 col-12 border my-2">
                                <div class="row">
                                    <div class="col-6 my-2">
                                        <h3>Special Price</h3>
                                        <div class="form-check form-switch">
                                            <input type="checkbox"<?php if($special_price == 1){
                                                echo $checked;
                                            } ?>
                                             class="form-check-input" name="specialPrice" value="1">
                                        </div>
                                    </div>
                                    <div class="col-6 my-2">
                                        <h3>Product for Slider</h3>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" <?php if($slider_img !=null){
                                                echo $checked;
                                            } ?>
                                             name="sliderImgCheckbtn" class="form-check-input" id="sliderImgBtn" onclick="sliderimgshoe()">
                                        </div>
                                    </div>
                                    <div class="col-6 my-2">
                                        <h3>Not Discountable</h3>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" <?php if($discount == 1){
                                                echo $checked;
                                            } ?> class="form-check-input" name="discount">
                                        </div>
                                    </div>
                                </div>
                                <div class="row display-none" id="sliderDIv">
                                    <div class="col-12 font-size-18 my-2">
                                        <input type="file" name="sliderImages" class="form-control font-size-18">
                                    </div>
                                </div>
                                <div class="row">
                                    <h3 class="py-3">Product Option </h3>
                                    <?php 
                                        for($i=0; $i<$x; $i++){

                                      ?>
                                    <div class="col-6 my-1">
                                        <div class="d-flex justify-content-around ">
                                            <input type="checkbox" <?php 
                                            $op_id_c = $result[$i]['op_id'];
                                            if(in_array($op_id_c,$op_id_array)){
                                                echo $checked;
                                            } ?> class="form-check" name="op_product[]" value="<?php echo $result[$i]['op_id']; ?>">
                                            <label class="form-check-label font-size-16 align-items-center"><?php echo $result[$i]['op_name']; ?> </label>
                                        </div>
                                    </div>
                                    <?php } ?>
                                  
                                </div>
                            </div>
                        </div>
                        <input type="text" value="<?php echo $pid; ?>" hidden name="pid">
                        <input type="text" value="<?php echo $page ;?>" hidden name="page">
                        <div class="form-group my-4">
                            <button class="w-100 btn color-primary-bg text-white report_btn font-size-20" name="product_update_btn">Update Product</button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
         </div>
      </div>
   </Section>
<script>
    function getSubcategory(datavalue){
		$.ajax({
			url : "ajax.php",
			type : "POST",
			data : {datapost : datavalue },
			success: function(result){
				$("#subCategory").html(result);
			}



		});
	}
    const sliderimgshoe = ()=>{
        let sliderImgBtn = document.getElementById('sliderImgBtn');
    let sliderDIv = document.getElementById("sliderDIv");
    if(sliderImgBtn.checked  == true){
        sliderDIv.style.display="block";
    }else{
        sliderDIv.style.display="none";
    }

    }
   
</script>
  