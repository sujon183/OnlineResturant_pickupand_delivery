<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
                <?php  unset($_SESSION['msg']);  } ?>
   <Section id="main">
      
        <section id="offerProducts" class="py-3 mx-3">
            <div class="card">
                <div class="card-header">
                   <h1 class="page-title mb-2">Users</h1>
                </div>
                <div class="card-body">   
                   <table class="table table-striped table-hover my-3 text-center">
                    <thead class="color-white-50-bg font-size-16 font-playfair">
                        <tr>
                           <th>ID</th>
                           <th>Name</th>
                           <th>Email</th>
                           <th>Phone</th>
                           <th> Password</th>
                           <th> Added On</th>
                           <th> Status</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-16">
                        <tr>
                            <td>1</td>
                            <td>Md Sujo Hossain</td>
                            <td> Sujon Hossain</td>
                            <td> 01580615042</td>
                            <td> $2y$10$Ijcv/f.hwb6L.PReqWEnrOGMrvxLShO6m4jf3/c94/SFuyH58oJUy</td>
                            <td> 2022-11-30 03:50:45</td>
                            <td> <span class="bg-success p-2 text-white">Active</span></td>
                           
                           
                       </tr>
                        <tr>
                            <td>1</td>
                            <td>Md Sujo Hossain</td>
                            <td> Sujon Hossain</td>
                            <td> 01580615042</td>
                            <td> $2y$10$Ijcv/f.hwb6L.PReqWEnrOGMrvxLShO6m4jf3/c94/SFuyH58oJUy</td>
                            <td> 2022-11-30 03:50:45</td>
                            <td> <span class="bg-success p-2 text-white">Active</span></td>
                           
                           
                       </tr>
                        <tr>
                            <td>1</td>
                            <td>Md Sujo Hossain</td>
                            <td> Sujon Hossain</td>
                            <td> 01580615042</td>
                            <td> $2y$10$Ijcv/f.hwb6L.PReqWEnrOGMrvxLShO6m4jf3/c94/SFuyH58oJUy</td>
                            <td> 2022-11-30 03:50:45</td>
                            <td> <span class="bg-success p-2 text-white">Active</span></td>
                           
                           
                       </tr>
                        <tr>
                            <td>1</td>
                            <td>Md Sujo Hossain</td>
                            <td> Sujon Hossain</td>
                            <td> 01580615042</td>
                            <td> $2y$10$Ijcv/f.hwb6L.PReqWEnrOGMrvxLShO6m4jf3/c94/SFuyH58oJUy</td>
                            <td> 2022-11-30 03:50:45</td>
                            <td> <span class="bg-danger p-2 text-white">Deactive</span></td>
                           
                           
                       </tr>
                     
                    </tbody>
                 </table>
                </div>
                <div class="card-footer">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="font-size-16">Showing 1 to 4 items of 4 Entries</p>
                        <nav aria-label="Page navigation example" class="mypagination">
                            <ul class="pagination">
                              <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                  <span aria-hidden="true">&laquo;</span>
                                </a>
                              </li>
                              <li class="page-item"><a class="page-link" href="#">1</a></li>
                              <li class="page-item"><a class="page-link" href="#">2</a></li>
                              <li class="page-item"><a class="page-link" href="#">3</a></li>
                              <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                  <span aria-hidden="true">&raquo;</span>
                                </a>
                              </li>
                            </ul>
                          </nav>
                    </div>
                </div>
            </div>
        </section>
   </Section>

  