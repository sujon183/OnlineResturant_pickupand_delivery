<?php 
        if(isset($_SESSION['msg'])){
        
        ?>
        <div class="row justify-content-center">
            <div class="col-4">

          
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong class="font-size-20 text-center">hay </strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                </div>
        </div>
<?php  unset($_SESSION['msg']);  } ?>

<?php
$db_obj->select('coupon_master',"*",null,null,null,5,1);
$pagination = $db_obj->pagination('coupon_master',null,null,5,1);
$result = $db_obj->getResult();
$result = $result[0];
$x = count($result);

if(isset($_GET['page'])){
    $page = $_GET['page'];

}else{
    $page =1;
}




?>
  
        <!-- total order with select time  -->
    <div class="container">
         <div class="row justify-content-center my-5">
        <div class="col-12">
           
                <h1 class="font-playfair  text-capitalize color-primary mb-5 report-table-title "> 
                    <a href="add-coupon.php">Add Coupon</a>
                </h1>
                <table class="table table-striped table-hover text-center">
                    <thead class=" text-capitalize font-size-20 font-playfair">
                        <tr>
                            <th>SL.</th>
                            <th>Coupon Code</th>
                            <th>Coupon Value</th>
                            <th>Minimum Amount</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody class="font-size-18">
                        <?php
                        for($i=0; $i<$x; $i++) { ?>
                        <tr>
                            <td><?php echo $i+1; ?></td>
                            <td><?php echo $result[$i]['coup_code']; ?></td>
                            <td><?php echo $result[$i]['coupon_value']; ?><span class="fa-solid fa-euro"></span></td>
                            <td><?php echo $result[$i]['min_amount']; ?><span class="fa-solid fa-euro"></span></td>
                            <td><?php echo $result[$i]['start_time']; ?></td>
                            <td><?php echo $result[$i]['end_time']; ?></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="./form_recurtion/coupon-master-ac.php" method="post" class="px-1">
                                        <input value="<?php echo $page ?>" name="page" hidden>
                                        <input value="<?php echo $result[$i]['coupon_id']; ?>" name="coupon_id" hidden>
                                        <input value="<?php echo $result[$i]['coupon_active']; ?>" name="coupon_active" hidden>
                                        <?php
                                        $active =  $result[$i]['coupon_active'];
                                            if($active ==1){
                                        ?>
                                        <button type="submit" name="coupon_active_btn" class="font-size-16 btn btn-success">Active</button>
                                        <?php }else{ ?>
                                        <button type="submit" name="coupon_active_btn" class="font-size-16 btn btn-danger">Deactive</button>
                                        <?php } ?>
                                    </form>
                                    <form action="update-coupon.php" method="post" class="px-1">
                                        <input value="<?php echo $page ?>" name="page" hidden>
                                        <input value="<?php echo $result[$i]['coupon_id']; ?>" name="coupon_id" hidden>
                                        <button type="submit" name="update_coupon_id_send" class="font-size-16 btn btn-warning">Update</button>
                                    </form>
                                    <form action="./form_recurtion/coupon-master-ac.php" method="post" class="px-1">
                                        <input value="<?php echo $result[$i]['coupon_id']; ?>" name="coupon_id" hidden>
                                        <button type="submit" name="coupon_dlt_btn" class="font-size-16 btn btn-danger">Delete</button>
                                    </form>
                               </div>
                          </td>
                        </tr> 
                        <?php } ?>
                    </tbody>
                 </table>
                 <nav aria-label="Page navigation example" class="mypagination">
                   <?php echo $pagination; ?>
                  </nav>
            
        </div>
     </div>
 
    </div>
  </section>

