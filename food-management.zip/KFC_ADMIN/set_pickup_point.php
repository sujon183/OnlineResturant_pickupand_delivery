<?php
session_start();
include("./database/database.php");
include("./includes/header.php");
include("./template/__set_pickup_point.php");
include("./includes/footer.php");
?>