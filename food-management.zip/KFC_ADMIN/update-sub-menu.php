<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include("./database/database.php");
include("./includes/header.php");

if(isset($_POST['add_sub_menu'])){
    $menu_id = $_POST['main-menu'];
    $pages = $_POST['page'];
    $page = '?page='.$pages;
    $sub_menu_name = $_POST['sub_name'];
    $sub_menu_name = $_POST['sub_name'];
    $sub_menu_id = $_POST['sub_menu_id'];
    $where = "sub_menu_id =".$sub_menu_id;
    if(empty($menu_id) || empty($sub_menu_id) || empty($sub_menu_name)){
        $_SESSION['msg'] = "Something is wrong";
    }else{
        $db_obj->update('sub_menu',['sub_menu_name'=>$sub_menu_name,'menu_id'=>$menu_id],$where);

        header("location: sub-menu.php$page");
    }
}



include("./template/__update_sub_menu.php");
include("./includes/footer.php");




// session end 
}else{
    $_SESSION['msg'] = "Please Login First";
    header("location: admin_login.php");
  }








?>