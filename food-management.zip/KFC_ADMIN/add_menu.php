
<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include("./database/database.php");
if(isset($_POST["menu_add_btn"])){
    $name = $_POST["menu_name"];
    $menu_img = $_FILES["menu_img"];
    $menu_img_name = $menu_img['name'];
    $menu_img_tmp_name = $menu_img['tmp_name'];
    $promo= $_FILES["promo_img"];
    $promo_name = $promo['name'];
    $promo_name_tmp = $promo['tmp_name'];
    $token =  bin2hex(random_bytes(6));
    $menu_img_name_up =$token."_".$menu_img_name;
    $promo_name_up = $token."_".$promo_name;
    $ar_menu_img = explode(".",$menu_img_name);
    $ext_img = end($ar_menu_img);
    $ext_img = strtolower($ext_img);
    $ar_promo_img = explode(".",$promo_name);
    $ext_promo = end($ar_promo_img);
    $ext_promo = strtolower($ext_promo);
    $img_array_exten = array('jpg','png','jpeg');
    $dir = "assets/images";

    // move_uploaded_file($menu_img_tmp_name,"$dir/$menu_img_name_up");
    //      $db_obj->insert("menu",['menu_name'=>$name,'menu_img'=>$menu_img_name_up);

  if(empty($name) || empty($menu_img_name)){
    $_SESSION['msg'] = "Something is Missing, Please Check Your Input";
  }else{

    if(empty($promo_name)){
         move_uploaded_file($menu_img_tmp_name,"$dir/$menu_img_name_up");
         $db_obj->insert("menu",['menu_name'=>$name,'menu_img'=>$menu_img_name_up]);
         $_SESSION['msg'] = "menu Uploaded";
         header('location: menu.php');
    }else{
        move_uploaded_file($menu_img_tmp_name,"$dir/$menu_img_name_up");
        move_uploaded_file($promo_name_tmp,"$dir/$promo_name_up");
        $db_obj->insert("menu",['menu_name'=>$name,'menu_img'=>$menu_img_name_up,'menu_img_opt'=>$promo_name_up]);
        // $_SESSION['msg'] = "menu Uploaded with promo code";
        header('location: menu.php');
    }



  }


}




?>
<?php include("./includes/header.php"); ?>

<?php include("./template/__add_menu.php");  ?>












<?php include("./includes/footer.php");

// session end 
}else{
  $_SESSION['msg'] = "Please Login First";
  header("location: admin_login.php");
}

?>

