<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include("./database/database.php");

if(isset($_POST['op_pro_up'])){
     $name = $_POST['op_name'];
    $op_id = $_POST['op_id'];
    $where = 'op_id='.$op_id;
    $page = $_POST['page'];
    if(empty($name)){
        $_SESSION['msg'] = "Something is wrong";
        header("location: option-product.php? page= $page");
    }else{
        $db_obj->update('op_product',['op_name'=>$name],$where);
        header("location: option-product.php");
        $_SESSION['msg'] = "Updated";
    }
}









// delete option product  
 
if(isset($_POST['op_pro_dlt'])){
    $op_id = $_POST['option_id'];
    $where = 'op_id='.$op_id;
    $db_obj->delete('op_product',$where);
    header("location: option-product.php");

}

// if(isset($_POST['add_op_id_btn_delete'])){
//    $add_op_id = $_POST['add_op_id'];
//    $where = "add_op_id =".$add_op_id;
//    $db_obj->delete('add_op_product	',$where);
// }



include("./includes/header.php");
include("./template/__update_option_product.php");
include("./includes/footer.php");


// session end 
}else{
    $_SESSION['msg'] = "Please Login First";
    header("location: admin_login.php");
  }

?>