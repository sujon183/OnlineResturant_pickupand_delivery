
    <!-- sidebar  -->
    <aside id="sidebar" class="sidebarStyle">
            <div class="d-flex flex-column py-5 my-5 font-size-16">
                <div class="dashboard mt-2"><a href="report.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Dashboard</a></div>
                <div class="dashboard mt-2"><a href="#" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Order Master</a></div>
                <div class="dashboard mt-2"><a href="#" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Complete Order Master</a></div>
                <div class="dashboard mt-2"><a href="menu.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Menu Master</a></div>
                <div class="dashboard mt-2"><a href="sub-menu.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; SubMenu  Master</a></div>
                <div class="dashboard mt-2"><a href="product.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Product  Master</a></div>
                <div class="dashboard mt-2"><a href="offer-product.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Offer  Products</a></div>
                <div class="dashboard mt-2"><a href="#" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; User Master</a></div>
                <div class="dashboard mt-2"><a href="delivery-boy.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Delivery Boy</a></div>
                <div class="dashboard mt-2"><a href="set-delivery-charge.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Set Delivery Charge</a></div>
                <div class="dashboard mt-2"><a href="set_pickup_point.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Set Pickup Point</a></div>
                <div class="dashboard mt-2"><a href="coupon-master.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Coupon Master</a></div>
                <div class="dashboard mt-2"><a href="#" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Setting</a></div>
                <div class="dashboard mt-2"><a href="manage_logo.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Manage Home</a></div>
                <div class="dashboard mt-2"><a href="admin.php" class="text-decoration-none"><span class="fa-solid fa-arrow-right"></span> &nbsp; Admin Home</a></div>
            </div>
        </aside>
    <!-- !sidebar  -->
