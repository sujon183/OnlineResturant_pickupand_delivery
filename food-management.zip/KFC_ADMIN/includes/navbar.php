    <!-- navbar  -->
    <nav class="navbar">
        <div class="menu-icons">
            <div class="open" id="open"><span class="fa-solid fa-bars"></span></div>
            <div class="close display-none" id="close"><span class="fa-solid fa-xmark"></span></div>
        </div>
        <div class="brand">
            <h3 class="navbar-brand color-primary">KFC</h3>
        </div>
        <div class="users">
            <h4 class="user_name">Admin</h4>
            <div class="profile"><span class="fa-solid fa-user"></span></div>
        </div>
    </nav>
    <!-- !navbar  -->