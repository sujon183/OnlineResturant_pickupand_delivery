<?php
session_start();
include("./database/database.php");
if(isset($_POST["admin_login_btn"])){
   
    $name = $_POST['usName'];
    $pass = $_POST['pass'];
    if(empty($name) || empty($pass)){
        $_SESSION['msg'] = "Something is Wrong, Please Check Your Input";
    }else{
    //    echo  $where = "name =".$name." AND pass=".$pass;
        $where = 'name='."'$name'".' AND pass='."'$pass'";

       $db_obj->select("admin_pro","*",null,$where,null,null);
       $result = $db_obj->getResult();
       $result = $result[0];
       $x = count ($result);
       if($x == 1){
        $_SESSION["auth_02urfieoejdubccndddd"]= $name;
        header("location: ./index.php");
       }else{
        $_SESSION['msg'] = "Please Checked Your Password or userName";
       }
    }
}



include("./includes/header.php");
include("./template/__admin_login.php");
include("./includes/footer.php");


?>