<?php
session_start();
include("./database/database.php");
if(isset($_POST['setPickUp_point'])){
    $pick_point = $_POST['pick_point'];
    $openingTime = $_POST['openingTime'];
    $Closing = $_POST['Closing'];
    $PostCode = $_POST['PostCode'];

    if(empty($pick_point) || empty($openingTime) || empty($Closing) || empty($PostCode)){
        $_SESSION['msg'] = "Please Input Every Field";
    }else{
        $db_obj->insert('pickuppoint',['pickup_point'=>$pick_point,'opening'=>$openingTime,'closing'=>$Closing,'postal_code'=>$PostCode]);
       $_SESSION['msg'] = " Pickup Point has been Added";
        header("location: set_pickup_point.php");
    }
}
include("./includes/header.php");
include('./template/__add_set_pickup_point.php');
include("./includes/footer.php");




?>