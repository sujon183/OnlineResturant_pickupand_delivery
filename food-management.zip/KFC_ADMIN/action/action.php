<?php 
session_start();
include("../database/database.php");

// Active method of menu 
if(isset($_POST['menu_active_btn'])){
    $menu_id = $_POST['active_id'];
    $page = $_POST['url'];
     $where = "menu_id =".$menu_id;
      $db_obj->select('menu','active',null,$where,null,null);
   $x = $db_obj->getResult();
    $x = $x[0];
    $x = $x[0]['active'];
    if($x == 1){
        $db_obj->update('menu',['active'=>0],$where);
        header("location: ../menu.php?page=$page");
    }elseif($x == 0){
        $db_obj->update('menu',['active'=>1],$where);
        header("location: ../menu.php?page=$page");
    }
}



// delete method of menu 
if(isset($_POST['menu_delete_btn'])){
    $menu_id = $_POST['delete_id'];
    // $page = $_POST['url'];
    $where = "menu_id =".$menu_id;
    $db_obj->delete('menu',$where);
    header("location: ../menu.php");
}

// product active or deactive 
if(isset($_POST['product_active_btn'])){
    $page = $_POST['page'];
     $pid = $_POST['pro_id'];
    $where = "pid =".$pid;
    $active = $_POST['pro_active'];
    if($active == 1){
        $db_obj->update('product',['pro_active'=>'0'],$where);
        header("location: ../product.php?page=$page");
    }else{
        $db_obj->update('product',['pro_active'=>'1'],$where);
        header("location: ../product.php?page=$page"); 
    }
}

// product delete method 

if(isset($_POST['product_delete_btn'])){
    $pid = $_POST['pro_id'];
    $where = "pid=".$pid;
    $db_obj->delete('product',$where);
   $_SESSION['msg'] = "Product has been Deleted";
   header('location: ../product.php');
}

// promote_btn_update 

if(isset($_POST['promote_btn_update'])){
     $pid = $_POST['pid']; 
    $prom = $_POST['dealInfo'];
     $where = "pid =".$pid; "<br>";
     $page = $_POST['page'];
   
        $db_obj->update('product',['deal_satus'=>$prom],$where);
        header("location: ../product.php?page=$page");
    
}


// min_amount update;
if(isset($_POST['min_amount_btn'])){
    $min_amount = $_POST['amount'];
    $page = $_POST['page'];
    $db_obj->update('minimum_amount',['amount'=>$min_amount],'min_id=1');
    $_SESSION['msg'] = "Successfully Updated";
    header("location: ../offer-product.php?page=$page");

}


// offer product uploaded 
if(isset($_POST['offer_pr_up_btn'])){
    $name = $_POST['name'];
    $offer_img = $_FILES['offer_img'];
    $token =  bin2hex(random_bytes(6));
     $offer_img_name = $offer_img['name'];
    $offer_img_tmp_name = $offer_img['tmp_name'];
    $token .="_". $offer_img_name;
    $dir = "../assets/images";
    $img_ar = explode('.',$offer_img_name);
  $ext = end($img_ar);
    $ext = strtolower($ext);
    $ext_array = array('jpg','png','jpeg');

    if(empty($name) || empty($offer_img)){
        $_SESSION['msg'] = "Something is wrong";
    }else{
        if(in_array($ext,$ext_array)){
            move_uploaded_file($offer_img_tmp_name, "$dir/$token");
            $db_obj->insert('offer_product',['offer_pr_name'=>$name,'offer_img'=>$token]);
        $_SESSION['msg'] = "Product has been Uploaded";
        header('location: ../offer-product.php');
        }else{
            $_SESSION['msg'] = "Please Upload a Image file";
            header('location: ../offer-product.php');
        }
        
    }

}


// offer_pr_dlt_btn
if(isset($_POST['offer_pr_dlt_btn'])){
    $of_id = $_POST['of_id'];
    $where = "of_id =".$of_id;
    $db_obj->delete('offer_product',$where);
    $_SESSION['msg'] = "Product has been Deleted";
    header('location: ../offer-product.php');
    
}

?>


