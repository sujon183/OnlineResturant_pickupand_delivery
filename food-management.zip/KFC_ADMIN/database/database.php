<?php 
class Database{

    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $dbName = "kfc";
    
   private  $result = array();
   private $sqlResult = array();
   private $joinResult = array();
   private $whereResult = array();
   private  $mysqli = "";
   private $conn = false;
   private $inserResult = array();


   public function __construct(){
    if(!$this->conn){
        $this->mysqli = new mysqli($this->host, $this->user, $this->pass, $this->dbName);
        if($this->mysqli->connect_error){
            array_push($this->result, $this->mysqli->connect_error);
            return false;
        }
    }else{
        return true;
    }

}  

    // insert method 

    public function insert($table,$prams=array()){
        echo "<pre>";
        //    print_r($prams);
         echo "</pre>";

         if($this->tableExists($table)){
            
            $table_column = implode(",",array_keys($prams));
            // print_r($table_column);
            $table_values = implode("','",$prams);
            // print_r($table_values);
            $sql = "INSERT INTO $table ($table_column) VALUES ('$table_values')";
            // echo $sql;
            if($this->mysqli->query($sql)){
                array_push($this->inserResult,$this->mysqli->insert_id);
                return true;
            }else{
                array_push($this->inserResult,$this->mysqli->error);
                return false;
            }
         }else{
            return false;
         }
       
    } // insert method close 

    public function update($table,$prams=array(),$where=null){
        // print_r($prams);
        if($this->tableExists($table)){
            $args = array();
           foreach($prams as $key =>$val){
            $args[] = "$key = '$val'";

           }
        //    print_r($args);
        $sql = " UPDATE $table SET ".implode(", ",$args);
        if($where != null){
            $sql .= " WHERE $where";
        }
        // echo $sql;
        if($this->mysqli->query($sql)){
            array_push($this->result,$this->mysqli->affected_rows);
            return true;
        }else{
            array_push($this->result,$this->mysqli->error);
            return false;
        }
        }

    }  //update method close 


    public function delete($table,$where=null){
        if($this->tableExists($table)){
            $sql = "DELETE FROM $table";
            if($where != null){
                $sql .= " WHERE $where";
            }
            if($this->mysqli->query($sql)){
                array_push($this->result, $this->mysqli->affected_rows);
                return true;
            }else{
                array_push($this->result, $this->mysqli->error);
                return false;
            }
            // echo $sql;
        }
    } // delete method close 


    public function sql($sql){
        $query = $this->mysqli->query($sql);
        if($query){
            $this->sqlResult = array();
            array_push($this->sqlResult,$query->fetch_all(MYSQLI_ASSOC));
            return true;
        }else{
            array_push($this->sqlResult,$this->mysqli->error);
            return false;
        }
    } // close sql method 
  

    public function selectWhere($table, $rows="*", $join = null, $where = null,$order = null, $limit = null){
        if($this->tableExists($table)){
            $sql = " SELECT $rows FROM $table";
            if($join !=null){
                $sql .= " JOIN $join";
            }
            if($where !=null){
                $sql .= "  $where";
            }
            if($order != null){
                $sql .= " ORDER BY $order";
            }
          
            if($limit != null){
                if(isset($_GET['page'])){
                    $page = $_GET['page'];
                }else{
                    $page = 1;
                }
                $start = ($page -1) * $limit;
                $sql .= " LIMIT $start,$limit";
            }
            // echo $sql;
            // echo "\n \n";
               
    
            // $url = basename($_SERVER["PHP_SELF"]);

            $query = $this->mysqli->query($sql);
            if($query){
                $this->whereResult=array();
                array_push($this->whereResult, $query->fetch_all(MYSQLI_ASSOC));
                return true;
            }else{
                array_push($this->whereResult, $this->mysqli->error);
                return false;
            }
            
            // echo $sql;
        }
    } // close selct method 
    public function select($table, $rows="*", $join = null, $where = null,$order = null, $limit = null){
        if($this->tableExists($table)){
            $sql = " SELECT $rows FROM $table";
            if($join !=null){
                $sql .= " JOIN $join";
            }
            if($where !=null){
                $sql .= " WHERE $where";
            }
            if($order != null){
                $sql .= " ORDER BY $order";
            }
          
            if($limit != null){
                if(isset($_GET['page'])){
                    $page = $_GET['page'];
                }else{
                    $page = 1;
                }
                $start = ($page -1) * $limit;
                $sql .= " LIMIT $start,$limit";
            }
            // echo $sql;
            // echo "\n \n";
               
    
            // $url = basename($_SERVER["PHP_SELF"]);

            $query = $this->mysqli->query($sql);
            if($query){
                $this->result = array();
                array_push($this->result, $query->fetch_all(MYSQLI_ASSOC));
                return true;
            }else{
                array_push($this->result, $this->mysqli->error);
                return false;
            }
            
            // echo $sql;
        }
    } // close selct method 

    public function selectInner($table, $rows="*", $join = null, $where = null,$order = null, $limit = null){
        if($this->tableExists($table)){
            $sql = " SELECT $rows FROM $table";
            if($join !=null){
                $sql .= "  $join";
            }
            if($where !=null){
                $sql .= " WHERE $where";
            }
            if($order != null){
                $sql .= " ORDER BY $order";
            }
          
            if($limit != null){
                if(isset($_GET['page'])){
                    $page = $_GET['page'];
                }else{
                    $page = 1;
                }
                $start = ($page -1) * $limit;
                $sql .= " LIMIT $start,$limit";
            }
            // echo $sql;
            // echo "\n \n";
               
    
            // $url = basename($_SERVER["PHP_SELF"]);

            $query = $this->mysqli->query($sql);
            if($query){
                $this->joinResult = array();
                array_push($this->joinResult, $query->fetch_all(MYSQLI_ASSOC));
                return true;
            }else{
                array_push($this->joinResult, $this->mysqli->error);
                return false;
            }
            
            // echo $sql;
        }
    } // close selct method 

    // pagination 

    public function paginationJoin($table,$join=null,$where=null,$limit=null){
       if($this->tableExists($table)){

        $sql = "SELECT COUNT(*) FROM $table";
        if($join != null){
            $sql .= "  $join";
        }
        if($where != null){
            $sql .= " WHERE $where";
        }
        // if($limit !=null){
        //     $sql .= " LIMIT 0 $limit";
        // }
        // echo $sql;
        
        $query = $this->mysqli->query($sql);

        $total_record = $query->fetch_array();
       
        // echo "<pre>";
        // print_r($total_record);
        // echo "</pre>";
        $total_record = $total_record[0];
        $total_page = ceil($total_record/$limit);
       $url = basename($_SERVER['PHP_SELF']);

       if(isset($_GET['page'])){
        $page = $_GET['page'];
       }else{
        $page = 1;
       }
       $outPut = "<ul class='pagination'>";
       if($page>1){
        $outPut .= "<li class='page-item'><a href='$url?page=".($page-1)."' class='page-link'>Prev</a></li>";
       }
        if($total_record>$limit){
            for($i=1; $i<= $total_page; $i++){
                if($i == $page){
                    $cls = "class='page-item active'";
                }else{
                    $cls = "class='page-item'";
                }
                $outPut .= "<li $cls><a class='page-link' href='$url?page=$i'>$i</a></li>";
            }
        }
        if($total_page>$page){
            $outPut .= "<li class='page-item'><a href='$url?page=".($page+1)."' class='page-link'>Next</a></li>";
           }
       $outPut .= "</ul";
       return $outPut;
       
       }else{
        return false;
       }
        
    }
    public function pagination($table,$join=null,$where=null,$limit=null){
       if($this->tableExists($table)){

        $sql = "SELECT COUNT(*) FROM $table";
        if($join != null){
            $sql .= " JOIN $join";
        }
        if($where != null){
            $sql .= " WHERE $where";
        }
        // if($limit !=null){
        //     $sql .= " LIMIT 0 $limit";
        // }
        // echo $sql;
        
        $query = $this->mysqli->query($sql);

        $total_record = $query->fetch_array();
       
        // echo "<pre>";
        // print_r($total_record);
        // echo "</pre>";
        $total_record = $total_record[0];
        $total_page = ceil($total_record/$limit);
       $url = basename($_SERVER['PHP_SELF']);

       if(isset($_GET['page'])){
        $page = $_GET['page'];
       }else{
        $page = 1;
       }
       $outPut = "<ul class='pagination'>";
       if($page>1){
        $outPut .= "<li class='page-item'><a href='$url?page=".($page-1)."' class='page-link'>Prev</a></li>";
       }
        if($total_record>$limit){
            for($i=1; $i<= $total_page; $i++){
                if($i == $page){
                    $cls = "class='page-item active'";
                }else{
                    $cls = "class='page-item'";
                }
                $outPut .= "<li $cls><a class='page-link' href='$url?page=$i'>$i</a></li>";
            }
        }
        if($total_page>$page){
            $outPut .= "<li class='page-item'><a href='$url?page=".($page+1)."' class='page-link'>Next</a></li>";
           }
       $outPut .= "</ul";
       return $outPut;
       
       }else{
        return false;
       }
        
    }

    // pagination close 


    // table exists 
       private  function tableExists($table){
            $sql = "SHOW TABLES FROM $this->dbName LIKE '$table'";
            $tableInDb = $this->mysqli->query($sql);
            if($tableInDb){
                if($tableInDb->num_rows == 1){
                    return true;
                }else{
                    array_push($this->result,$table." Does not Exists in this Database.");
                    return false;
                }
            }
          
            
        }  // tableExists method close 

  public function getResult(){
            $val = array();
            $val = $this->result;
            $result = array();
            return $val;
        } // getResult close 
  public function getInsertResult(){
            $val = array();
            $val = $this->inserResult;
            $result = array();
            return $val;
        } // get Insert Result close 
  public function whereResult(){
            $val = array();
            $val = $this->whereResult;
            $whereResult = array();
            return $val;
        } // getResult close 
        public function getsqlResult(){
            $val = array();
            $val = $this->sqlResult;
            $sqlResult = array();
            return $val;
        } // get sql result close 
        public function getjoinResult(){
            $val = array();
            $val = $this->joinResult;
            $sqlResult = array();
            return $val;
        } // get join result close 

      



  


    public function __distruct(){
        if($this->conn){
            if($this->mysqli->close()){
                $this->conn = false;
                return true;
            }
        }else{
            return false;
        }
    }  // close distruct method 

}  // database class close

$db_obj = new Database()


?>