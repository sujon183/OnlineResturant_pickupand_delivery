<?php
session_start();
include("../database/database.php");

// top logo manage 

if(isset($_POST['btn_add_top_lg'])){
   $top_logo = $_FILES['top_logo'];
   $img_name = $top_logo['name'];
   $tmp_name = $top_logo['tmp_name'];
   $dir = "../assets/logo";
   $token = bin2hex(random_bytes(6));
   $img_ext_arr = array('jpg','png','jpeg');
   $img_arr = explode(".",$img_name);
   $ext = end($img_arr);
   $ext = strtolower($ext);
   $where = "t_logo_id = 1";
   $img_name_up = $token."_". $img_name;
   if(empty($img_name)){
    $_SESSION['msg'] = "Please Insert Top logo Image";
    header("location:  ../manage_logo.php");
   }else{
    
    if(in_array($ext,$img_ext_arr)){
        move_uploaded_file($tmp_name,"$dir/$img_name_up");
        $_SESSION['msg'] = "top Logo has been Updated";
        $db_obj->update("top_logo",['top_logo_name'=>$img_name_up],$where);
        header("location:  ../manage_logo.php");


    }else{
        $_SESSION['msg'] = "Please Upload Image File";
        header("location:  ../manage_logo.php");
    }
   }
}

// footer logo manage 

if(isset($_POST['btn_add_bottom_lg'])){
   $name = $_FILES['footer_logo']; 
   $img_name = $name['name'];
   $tmp_name = $name['tmp_name'];
   $token = bin2hex(random_bytes(6));
   $array = ['jpg','png','jpeg'];
   $img_arr = explode('.',$img_name);
   $ext = strtolower(end($img_arr));
   $img_up_name = $token."_". $img_name;
   if(empty($img_name)){
    $_SESSION['msg'] = "Please Insert Image";
    header("location:  ../manage_logo.php");  
   }else{
    if(in_array($ext,$array)){
        move_uploaded_file($tmp_name,"$dir/$img_up_name");
        $db_obj->update('footer_logo',['footer_logo_name'=>$img_up_name],'f_logo_id=1');
        $_SESSION['msg'] = "Foorter Image Updated  Has been Success";
        header("location:  ../manage_logo.php");  
    }else{
        $_SESSION['msg'] = "Please Upload an Image File";
        header("location:  ../manage_logo.php");  
    }
   }
}

// site identity manage   

if(isset($_POST['site_info_btn'])){
    $site_title =$_POST['site_title'];
    $site_phone_number =$_POST['site_phone_number'];
    $fb_adress =$_POST['fb_adress'];
    $whatsapp_num =$_POST['whatsapp_num'];
    $c_address =$_POST['c_address'];
    $site_info_id =$_POST['site_info_id'];
    $where = "site_id = 1";
    $db_obj->update("site_info",['site_title'=>$site_title,'site_phone_num'=>$site_phone_number,
    'fb_url'=>$fb_adress,'whatsapp_number'=>$whatsapp_num,'company_address'=>$c_address],$where);
    $_SESSION['msg'] = "Site info has been updated";
    header("location:  ../manage_logo.php");  
    
}

?>