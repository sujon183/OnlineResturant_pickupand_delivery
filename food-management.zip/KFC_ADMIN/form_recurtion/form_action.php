<?php
session_start();
include("../database/database.php");
if(isset($_POST["menu_add_btn"])){
    $name = $_POST["menu_name"];
    $menu_img = $_FILES["menu_img"];
    $menu_img_name = $menu_img['name'];
    $menu_img_tmp_name = $menu_img['tmp_name'];
    $promo= $_FILES["promo_img"];
    $promo_name = $promo['name'];
    $promo_name_tmp = $promo['tmp_name'];
    $token =  bin2hex(random_bytes(6));
    $menu_img_name =$token."_".$menu_img_name;
    $promo_name = $token."_".$promo_name;
    $ar_menu_img = explode(".",$menu_img_name);
    $ext_img = end($ar_menu_img);
    $ext_img = strtolower($ext_img);
    $ar_promo_img = explode(".",$promo_name);
    $ext_promo = end($ar_promo_img);
    $ext_promo = strtolower($ext_promo);
    $img_array_exten = array('jpg','png','jpeg');
    $dir = "./assets/images";
    if(empty($name) || empty($menu_img)){
       $_SESSION['msg']= " Something is Wrong";
       header("location: add_menu.php"); 
    }else{
       if(in_array($ext_img,$img_array_exten)){
            if($promo != null){
                if(in_array($ext_promo,$img_array_exten)){
                    // here fire the query 
                }else{
                    $_SESSION['msg']= " You Upload  Unexpected file";
                }
            }else{
                move_uploaded_file($menu_img_tmp_name,'$dir/$menu_img_name');
            }
       }else{
        $_SESSION['msg']= " You Upload  Unexpected file";
       } 
    }
    
}

// unpaid option product add 
if(isset($_POST['add_option_product_btn_unpaid'])){
     $name = $_POST['name'];
    $op_type = $_POST['op_type'];
    $description = $_POST['description'];
    $img = $_FILES['img'];
    $img_tmp = $img['tmp_name'];
    $img_name = $img['name'];
    $img_arr = explode('.',$img_name);
    $file_ext = end($img_arr);
    $file_ext = strtolower($file_ext);
    $ext_array = array('jpg','png','jpeg');
    $token =  bin2hex(random_bytes(6));
     $token .= '_'.$img_name;
    
       
     $dir = "../assets/images";
  
    $op_id = $_POST['op_id'];
   $op_name = $_POST['op_name'];
    
 
    if(empty($name) || empty($description) || empty($img)){
     $_SESSION['msg'] = "Something is Wrong";
     header("location: ../update_option.php");
    }else{
     if(in_array($file_ext,$ext_array)){
         move_uploaded_file($img_tmp, "$dir/$token");
         $db_obj->insert('add_op_product',['name'=>$name, 'description'=>$description, 'op_pr_img'=>$token, 'op_id'=>$op_id]);
         header("location: ../update_option_product.php");
         $_SESSION['added_product_info'] = ['op_id'=>$op_id, 'op_name'=>$op_name,'op_type'=>$op_type];
     }else{
         $_SESSION['msg'] = "Please Upload a Image file";
         header('location: ../product-option.php');
     }
    }
 
 }


 // paid option product add 
 if(isset($_POST['add_option_product_btn_paid'])){
    $name = $_POST['name'];
    $op_type = $_POST['op_type'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $img = $_FILES['img'];
    $img_tmp = $img['tmp_name'];
    $img_name = $img['name'];
    $img_arr = explode('.',$img_name);
    $file_ext = end($img_arr);
    $file_ext = strtolower($file_ext);
    $ext_array = array('jpg','png','jpeg');
    $token =  bin2hex(random_bytes(6));
     $token .= '_'.$img_name;
    
 
     $dir = "../assets/images";
  
    $op_id = $_POST['op_id'];
   $op_name = $_POST['op_name'];
    
 
    if(empty($name) || empty($description) || empty($img) || empty($price)){
     $_SESSION['msg'] = "Something is Wrong";
     header("location: ./update_option.php");
    }else{
     if(in_array($file_ext,$ext_array)){
         move_uploaded_file($img_tmp, "$dir/$token");
         $db_obj->insert('add_op_product',['name'=>$name, 'description'=>$description, 'price'=>$price, 'op_pr_img'=>$token, 'op_id'=>$op_id]);
         header("location: ../update_option_product.php");
         $_SESSION['added_product_info'] = ['op_id'=>$op_id, 'op_name'=>$op_name,'op_type'=>$op_type];
     }else{
         $_SESSION['msg'] = "Please Upload a Image file";
         header('location: product-option.php');
     }
    }
 
 }

//  product delete option method 

if(isset($_POST['product_option_dlt_btn'])){
    $op_id = $_POST['op_id'];
    $op_name = $_POST['op_name'];
    $op_type = $_POST['op_type'];
    $add_op_id = $_POST['add_op_id'];
    $where = 'add_op_id ='.$add_op_id;
    $db_obj->delete('add_op_product',$where);
    header("location: ../update_option_product.php");
         $_SESSION['added_product_info'] = ['op_id'=>$op_id, 'op_name'=>$op_name,'op_type'=>$op_type];
}



?>