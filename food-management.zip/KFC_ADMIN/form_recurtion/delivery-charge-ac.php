<?php
session_start();
include('../database/database.php');

// add deliver-charge 
if(isset($_POST['delivery_charge_btn_sub'])){
    $point_name = $_POST['point_name'];
    $charge_amount = $_POST['charge_amount'];
    if(empty($point_name) || empty($charge_amount)){
        $_SESSION['msg'] = "Something is wrong";
    }else{
        $db_obj->insert('delivery_charge',['point_name'=>$point_name, 'charge_amount'=>$charge_amount]);
        $_SESSION['msg'] = "Charge has been added successfully";
        header('location: ../set-delivery-charge.php');
    }
}

// active delivery charge 
if(isset($_POST['db_charge_ac_btn'])){
   $dcid = $_POST['dcid'];
   $where = "dcid =".$dcid;
   $page = $_POST['page'];
   $delivery_active = $_POST['delivery_active'];
   if($delivery_active == 1){
    $db_obj->update('delivery_charge',['delivery_active'=>0],$where);
    header("location: ../set-delivery-charge.php?page= $page ");
   }else{
    $db_obj->update('delivery_charge',['delivery_active'=>1],$where);
    header("location: ../set-delivery-charge.php?page= $page ");
   }
}

// delivery charge delete method 
if(isset($_POST['deliver_charge_dlt_btn'])){
    $dcid = $_POST['dcid'];
    $where = "dcid =".$dcid;
    $db_obj->delete('delivery_charge',$where);
    $_SESSION['msg'] = "it has been deleted";
    header('location: ../set-delivery-charge.php');

}

// delivery charge update btn 
if(isset($_POST['delivery_charge_up_btn_sub'])){
    $dcid = $_POST['dcid'];
    $page = $_POST['page'];
    $point_name = $_POST['point_name'];
    $charge_amount = $_POST['charge_amount'];
    if(empty($point_name) || empty($charge_amount)){
        $_SESSION['msg'] = "Something is wrong";
        $_SESSION['empty_something'] = ['dcid'=>$dcid, 'page'=>$page];
        header('location: ../update-delivery-charge.php');
    }else{
        $db_obj->update('delivery_charge',['point_name'=>$point_name, 'charge_amount'=>$point_name]);
        $_SESSION['msg'] = "Delivery charge update successfully";
        header("location: ../set-delivery-charge.php?page=$page");
    }
}

?>