<?php
session_start();
include("../database/database.php");

// add_coupon_btn 

if(isset($_POST['add_coupon_btn'])){
    $coupon_name = $_POST['coupon_name'];
    $coupon_value = $_POST['coupon_value'];
    $min_amount = $_POST['min_amount'];
    $strt_date = $_POST['strt_date'];
    $end_date = $_POST['end_date'];
    if(empty($coupon_name) || empty($coupon_value) || empty($min_amount) || empty($strt_date) || empty($end_date)){
        $_SESSION['msg'] = "Something is wrong";
        header('location: ../add-coupon.php');
    }else{
        $db_obj->insert('coupon_master',['coup_code'=>$coupon_name,'coupon_value'=>$coupon_value, 'min_amount'=>$min_amount, 'start_time'=>$strt_date, 'end_time'=>$end_date]);
        $_SESSION['msg'] = "Coupon uploaded successfull";
        header('location: ../coupon-master.php');
    }
}

    // active coupon 
    if(isset($_POST['coupon_active_btn'])){
        $page = $_POST['page'];
        $coupon_id = $_POST['coupon_id'];
        $where = "coupon_id =".$coupon_id;
        $coupon_active = $_POST['coupon_active'];
        if($coupon_active == 1){
            $db_obj->update('coupon_master',['coupon_active'=>0],$where);
            header("location: ../coupon-master.php?page=$page");
        }else{
            $db_obj->update('coupon_master',['coupon_active'=>1],$where);
            header("location: ../coupon-master.php?page=$page"); 
        }
    }


    // update coupon master 

    if(isset($_POST['update_coupon_btn'])){
        $coupon_name = $_POST['coupon_name'];
        $coupon_value = $_POST['coupon_value'];
        $min_amount = $_POST['min_amount'];
        $strt_date = $_POST['strt_date'];
        $end_date = $_POST['end_date'];
        $page = $_POST['page'];
        $coupon_id = $_POST['coupon_id'];
        $where = "coupon_id =".$coupon_id;
        if(empty($coupon_name) || empty($coupon_value) || empty($min_amount) || empty($strt_date) || empty($end_date)){
            $_SESSION['msg'] = "Something is wrong";
            $_SESSION['coupon_fail'] = ['coupon_id'=>$coupon_id, 'page'=>$page];
            header('location: ../update-coupon.php');
        }else{
            $db_obj->update('coupon_master',['coup_code'=>$coupon_name,'coupon_value'=>$coupon_value, 'min_amount'=>$min_amount, 'start_time'=>$strt_date, 'end_time'=>$end_date],$where);
            $_SESSION['msg'] = "Coupon Update successfull";
            header("location: ../coupon-master.php?page=$page");
        }
    }

    // coupon delete btn 
    if(isset($_POST['coupon_dlt_btn'])){
        $coupon_id = $_POST['coupon_id'];
        $where = "coupon_id =".$coupon_id;
        $_SESSION['msg'] = "Coupon has been Deleted";
        $db_obj->delete('coupon_master',$where);
        header("location: ../coupon-master.php");
    }




?>