<?php
session_start();
include("../database/database.php");
// delivery boy upload  
if(isset($_POST['db_boy_add_btn'])){
   $db_boy = $_POST['db_name'];
   $phone_no = $_POST['phone_no'];
   $db_pass = $_POST['db_pass'];
    $date = date("j-m-Y");
   // $haspass = sha1(md5($db_pass));
   if(empty($db_boy) || empty($phone_no) || empty($db_pass)){
        $_SESSION['msg']= "Something is wrong";
        header('location: ../add_delivery_boy.php');
   }else{
      if(strlen($db_pass) <= 3){
         $_SESSION['msg'] = "password Must be greater than three charecters";
         header('location: ../add_delivery_boy.php');
      }else{
         $db_obj->insert('delivery_boy',['deliver_boy_name'=>$db_boy, 'db_phone_number'=>$phone_no, 'db_pass'=>$db_pass,'date'=>$date]);
         $_SESSION['msg'] = "Delivery has been added successfully";
         header('location: ../delivery-boy.php');
      }
   
   }
}

// delivery boy active 
if(isset($_POST['db_active_btn'])){
   $dbid = $_POST['dbid'];
   $where = "dbid =".$dbid;
   $active = $_POST['active'];
   $page = $_POST['page'];
   if($active == 1){
      $db_obj->update('delivery_boy',['db_active'=>0],$where);
      header("location: ../delivery-boy.php?page=$page");
   }else{
      $db_obj->update('delivery_boy',['db_active'=>1],$where);
      header("location: ../delivery-boy.php?page=$page");
   }

}

// DELETE method
if(isset($_POST['db_boy_dlt_btn'])){
   $dbid = $_POST['dbid'];
   $where = "dbid =".$dbid;
   $db_obj->delete('delivery_boy',$where);
   $_SESSION['msg'] = "Delivery boy has been Deleted";
   header("location: ../delivery-boy.php");
}

// update delivery boy 
if(isset($_POST['db_boy_update_btn'])){
   $name = $_POST['db_name'];
   $phone_no = $_POST['phone_no'];
   $db_pass = $_POST['db_pass'];
   $page = $_POST['page'];
   $dbid = $_POST['dbid'];
   $where = "dbid =".$dbid;
   if(empty($name) || empty($phone_no) || empty($db_pass)){
      $_SESSION['msg'] = "Something is wrong";
      $_SESSION['xyz'] = ['dbid'=>$dbid,'page'=>$page];
      header("location: ../update-delivery-boy.php?page=$page");
   }else{
      $db_obj->update('delivery_boy',['deliver_boy_name'=>$name, 'db_phone_number'=>$phone_no, 'db_pass'=>$db_pass],$where);
      header("location: ../delivery-boy.php");
   }
}



?>