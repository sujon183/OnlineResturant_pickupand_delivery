$(document).ready(function(){
   
   $sideNavigate = $("#sidebar");
   $openBtn = $("#open");
   $closeBtn = $("#close");

   $openBtn.click(function(){
    $sideNavigate.css('left','0');
    $closeBtn.removeClass('display-none');
    $openBtn.addClass('display-none');
   });

   $closeBtn.click(function(){
    $sideNavigate.css('left','-25rem');
    $closeBtn.addClass('display-none');
    $openBtn.removeClass('display-none');
   });


   // add add product option  
   $add_product_mymodal = $('#mymodal');
   $add_product_open_btn = $('#Add_product_open_btn');
   $add_product_close_btn = $('#Add_product_close_btn');
 

   $add_product_open_btn.click(function(){
      $add_product_mymodal.css('top','3rem');
      
   })
   $add_product_close_btn.click(function(){
         $add_product_mymodal.css('top','-100rem');
   })
      // End add add product option  



   // paidable 
      $paidable_open = $('#paidable_btn');
      $paid_multiple_modal = $('#paid_multiple_modal');
      $paid_multiple_modal_close = $('#add_product_close_btn');

      $paidable_open.click(function(){
         $paid_multiple_modal.css('top','0');
      });
      $paid_multiple_modal_close.click(function(){
         $paid_multiple_modal.css('top','-100rem');
      });
     

   //   unpaidable 
      $un_paidable_btn = $('#un_paidable_btn');
      $unpaid_multiple_modal = $('#unpaid_multiple_modal');
      $unpaid_multiple_modal_close_btn = $('#unpaid_multiple_modal_close_btn');
      

      $un_paidable_btn.click(function(){
         $unpaid_multiple_modal.css('top','3rem');
      });
      $unpaid_multiple_modal_close_btn.click(function(){
         $unpaid_multiple_modal.css('top','-100rem');
      });




});


