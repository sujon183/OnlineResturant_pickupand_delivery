<?php
session_start();
if(isset($_SESSION['auth_02urfieoejdubccndddd'])){
include("./includes/header.php");

?>
<?php
include("./includes/footer.php");


// session End 
}else{
    $_SESSION['msg'] = "Please Login First";
    header("location: admin_login.php");
  }
?>